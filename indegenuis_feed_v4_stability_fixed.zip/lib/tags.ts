export const CANONICAL_TAGS = [
  "Law & Justice",
  "Economics",
  "Technology",
  "Public Health",
  "Politics & Governance",
  "Environment & Climate",
  "Education Policy",
  "Philosophy",
  "Gender Studies",
  "Business & Finance",
  "International Relations",
  "Computer Science",
  "Medicine",
  "Agriculture",
  "Literature & Writing",
  "History",
  "Human Rights",
  "Social Justice",
  "Engineering",
  "African Culture",
  "Nigeria",
  "Ghana",
  "Kenya",
  "South Africa",
  "Senegal",
  "Ethiopia",
  "Rwanda",
  "Uganda",
  "Morocco",
  "Egypt",
  "Tanzania",
  "Côte d'Ivoire",
  "West Africa",
  "East Africa",
  "Southern Africa",
  "North Africa",
  "Pan-African",
  "Youth",
  "Innovation",
  "Startups",
  "Climate Change",
] as const;

export type CanonicalTag = (typeof CANONICAL_TAGS)[number];

const COUNTRY_REGION_TAGS = CANONICAL_TAGS.slice(20, 37);
export const MAX_TOPIC_KEY_LENGTH = 80;
export const MAX_SHORT_POST_TOPICS = 3;
export const MAX_LONG_FORM_TOPICS = 5;
export const MAX_RESEARCH_KEYWORDS = 10;

/**
 * Strips the leading '#' authors type out of habit.
 *
 * Every surface that shows a topic renders its own '#' prefix, so a stored
 * "#africa" printed as "##africa". Worse than the cosmetics: an unstripped
 * hash made "#africa" and "africa" two different topic keys, quietly splitting
 * one topic's posts and subscribers across two pages.
 *
 * Trimmed before and after so "  # africa " normalizes the same as "#africa".
 */
export function stripTagHash(tag: string) {
  return tag.trim().replace(/^#+/, "").trim();
}

export function normalizeTagValue(tag: string) {
  return stripTagHash(tag).toLowerCase().replace(/\s+/g, " ");
}

/**
 * The display form of a stored tag: original casing, no leading hash.
 *
 * Distinct from `normalizeTagValue`, which lowercases for key comparison.
 * Callers render their own '#', so this must not add one. Rows written before
 * the hash was stripped on the way in still carry it, so display strips too
 * rather than trusting the stored value.
 */
export function formatTagLabel(tag: string) {
  return stripTagHash(tag);
}

export function isSubscribableTopicValue(tag: string) {
  const normalized = normalizeTagValue(tag);
  return normalized.length > 0 && normalized.length <= MAX_TOPIC_KEY_LENGTH;
}

export function getTopicValuesValidationError(tags: string[]) {
  const invalid = tags.find((tag) => {
    const normalized = normalizeTagValue(tag);
    return normalized.length < 1 || normalized.length > MAX_TOPIC_KEY_LENGTH;
  });
  return invalid
    ? `Each topic must contain between 1 and ${MAX_TOPIC_KEY_LENGTH} characters.`
    : null;
}

export function getCanonicalTagMatch(value: string | null | undefined) {
  if (!value) return null;

  const normalizedValue = normalizeTagValue(value);

  return (
    CANONICAL_TAGS.find((tag) => {
      const normalizedTag = normalizeTagValue(tag);
      return (
        normalizedTag === normalizedValue ||
        normalizedTag.includes(normalizedValue) ||
        normalizedValue.includes(normalizedTag)
      );
    }) ?? null
  );
}

export function getExactCanonicalTag(value: string | null | undefined) {
  if (!value) return null;
  const normalizedValue = normalizeTagValue(value);
  return (
    CANONICAL_TAGS.find(
      (tag) => normalizeTagValue(tag) === normalizedValue
    ) ?? null
  );
}

export function normalizeAndDedupeTopicValues(values: string[], limit: number) {
  const seen = new Set<string>();
  const normalized: string[] = [];

  for (const value of values) {
    const key = normalizeTagValue(value);
    if (!key || seen.has(key)) continue;
    seen.add(key);
    normalized.push(key);
    if (normalized.length >= limit) break;
  }

  return normalized;
}

export function normalizeResearchKeywords(values: string[]) {
  return normalizeAndDedupeTopicValues(values, MAX_RESEARCH_KEYWORDS);
}

/**
 * Existing editable Research drafts stored topics and keywords together in
 * posts.tags. Only exact canonical values can be identified safely as topics;
 * every other non-reserved value is treated as a legacy keyword on first save.
 */
export function splitLegacyResearchTags(values: string[]) {
  const topics: string[] = [];
  const keywords: string[] = [];

  for (const value of values) {
    const normalized = normalizeTagValue(value);
    if (!normalized || normalized === "research") continue;
    const canonical = getExactCanonicalTag(normalized);
    if (canonical) {
      topics.push(normalizeTagValue(canonical));
    } else {
      keywords.push(normalized);
    }
  }

  return {
    topics: normalizeAndDedupeTopicValues(topics, MAX_LONG_FORM_TOPICS),
    keywords: normalizeResearchKeywords(keywords),
  };
}

export function getSuggestedTags({
  content,
  fieldOfStudy,
  platformTags,
}: {
  content: string;
  fieldOfStudy?: string | null;
  platformTags?: string[];
}) {
  const suggestions: string[] = [];
  const normalizedContent = normalizeTagValue(content.replace(/<[^>]*>/g, " "));

  const fieldTag = getCanonicalTagMatch(fieldOfStudy);
  if (fieldTag) suggestions.push(fieldTag);

  COUNTRY_REGION_TAGS.forEach((tag) => {
    if (normalizedContent.includes(normalizeTagValue(tag))) {
      suggestions.push(tag);
    }
  });

  (platformTags ?? []).forEach((tag) => {
    const canonicalMatch = getCanonicalTagMatch(tag);
    if (canonicalMatch) suggestions.push(canonicalMatch);
  });

  return Array.from(new Set(suggestions)).slice(0, 5);
}
