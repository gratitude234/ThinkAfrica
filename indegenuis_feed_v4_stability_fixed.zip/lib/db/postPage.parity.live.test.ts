import { afterAll, beforeAll, describe, expect, it, vi } from "vitest";

vi.mock("server-only", () => ({}));

/**
 * PostgREST and PostgreSQL, reading the SAME production database, compared
 * field by field.
 *
 * This is the check that only exists at this stage of the migration, and it is
 * the strongest one available: both sides see identical rows at the same
 * instant, so any difference is a difference in the query, not in the data.
 * The Neon comparison could never say that, because Neon is a copy taken at a
 * different time.
 *
 * READ ONLY on both sides.
 *
 * Run with:  node scripts/migration/postpage-parity.mjs
 */

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL;
const serviceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
const directUrl = process.env.SUPABASE_DIRECT_URL;
const enabled = Boolean(supabaseUrl && serviceKey && directUrl);

const { createSupabasePostPageRepository, createPostgresPostPageRepository } =
  await import("@/lib/db/postPage");
const { adaptDriver } = await import("@/lib/db/postgres/executor");

import { canonical, differences } from "@/lib/db/parityDiff";

import type { PostPageRepository } from "@/lib/db/postPage";

describe.skipIf(!enabled)("post page: PostgREST vs PostgreSQL, same database", () => {
  let sql: Awaited<ReturnType<typeof open>>;
  let viaRest: PostPageRepository;
  let viaSql: PostPageRepository;
  let cases: Array<{ id: string; tags: string[]; publishedAt: string | null }>;

  async function open() {
    const { default: postgres } = await import("postgres");
    return postgres(directUrl!, {
      max: 1,
      prepare: false,
      connect_timeout: 20,
      fetch_types: false,
      onnotice: () => {},
    });
  }

  beforeAll(async () => {
    const { createClient } = await import("@supabase/supabase-js");
    viaRest = createSupabasePostPageRepository(
      createClient(supabaseUrl!, serviceKey!, {
        auth: { persistSession: false, autoRefreshToken: false },
      }) as never
    );

    sql = await open();
    viaSql = createPostgresPostPageRepository(adaptDriver(sql as never));

    // A spread of real posts: with references, with co-authors, with reviews,
    // and a plain one. A parity run over five identical
    // published essays proves the easy half.
    const rows = await sql.unsafe(`
      (select id::text as id, to_jsonb(tags) as tags, published_at from public.posts
         where status='published' and id in (select post_id from public.post_references) limit 2)
      union all
      (select id::text, to_jsonb(tags), published_at from public.posts
         where status='published' and id in (select post_id from public.post_authors) limit 2)
      union all
      (select id::text, to_jsonb(tags), published_at from public.posts
         where status='published' and id in (select post_id from public.post_reviews) limit 2)
      union all
      (select id::text, to_jsonb(tags), published_at from public.posts
         where status='published' order by published_at desc limit 3)
    `);

    const seen = new Set<string>();
    cases = [];
    for (const row of rows as unknown as Array<Record<string, unknown>>) {
      const id = String(row.id);
      if (seen.has(id)) continue;
      seen.add(id);
      cases.push({
        id,
        tags: (row.tags as string[]) ?? [],
        publishedAt: row.published_at
          ? new Date(row.published_at as string).toISOString()
          : null,
      });
    }

    expect(cases.length, "no published posts to compare").toBeGreaterThan(0);
  }, 180_000);

  afterAll(async () => {
    await sql?.end({ timeout: 5 });
  });

  it("returns identical counts", async () => {
    const mismatches: string[] = [];
    for (const testCase of cases) {
      const [rest, direct] = await Promise.all([
        viaRest.counts(testCase.id),
        viaSql.counts(testCase.id),
      ]);
      mismatches.push(
        ...differences(rest, direct, testCase.id).map((entry) => `counts ${entry}`)
      );
    }
    expect(mismatches, mismatches.join("\n")).toEqual([]);
  }, 300_000);

  it("returns identical collections, in the same order", async () => {
    const mismatches: string[] = [];
    for (const testCase of cases) {
      const [rest, direct] = await Promise.all([
        viaRest.collections(testCase.id, null),
        viaSql.collections(testCase.id, null),
      ]);

      // Ordering is part of the contract for references, so they are
      // compared positionally. The co-author, review, decision and version
      // collections went in the final UI simplification.
      mismatches.push(
        ...differences(rest.references, direct.references, `${testCase.id}.references`)
      );
      if (canonical(Object.keys(rest)) !== canonical(Object.keys(direct))) {
        mismatches.push(`${testCase.id} collection keys differ`);
      }
    }
    expect(mismatches, mismatches.join("\n")).toEqual([]);
  }, 300_000);

  it("returns identical related posts", async () => {
    const mismatches: string[] = [];
    for (const testCase of cases) {
      if (testCase.tags.length === 0) continue;
      const [rest, direct] = await Promise.all([
        viaRest.related(testCase.id, testCase.tags, 3, null),
        viaSql.related(testCase.id, testCase.tags, 3, null),
      ]);

      // `published_at desc` can tie, and neither side promises a tiebreak, so
      // the set is compared rather than the order.
      const ids = (list: Array<{ id: string }>) => list.map((e) => e.id).sort();
      if (canonical(ids(rest)) !== canonical(ids(direct))) {
        mismatches.push(
          `${testCase.id} related: ${ids(rest).join(",")} vs ${ids(direct).join(",")}`
        );
        continue;
      }

      const byId = new Map(direct.map((entry) => [entry.id, entry]));
      for (const entry of rest) {
        mismatches.push(
          ...differences(entry, byId.get(entry.id), `${testCase.id}.related.${entry.id}`)
        );
      }
    }
    expect(mismatches, mismatches.join("\n")).toEqual([]);
  }, 300_000);

  it("returns identical neighbours", async () => {
    const mismatches: string[] = [];
    for (const testCase of cases) {
      if (!testCase.publishedAt) continue;
      const [rest, direct] = await Promise.all([
        viaRest.neighbours(testCase.id, testCase.publishedAt),
        viaSql.neighbours(testCase.id, testCase.publishedAt),
      ]);
      mismatches.push(
        ...differences(rest, direct, `${testCase.id}.neighbours`)
      );
    }
    expect(mismatches, mismatches.join("\n")).toEqual([]);
  }, 300_000);

  it("returns identical viewer state", async () => {
    const rows = await sql.unsafe(
      `select l.user_id::text as viewer, l.post_id::text as post, p.author_id::text as author
       from public.likes as l join public.posts as p on p.id = l.post_id limit 3`
    );

    const mismatches: string[] = [];
    for (const row of rows as unknown as Array<Record<string, unknown>>) {
      const [rest, direct] = await Promise.all([
        viaRest.viewerState(String(row.post), String(row.viewer), String(row.author)),
        viaSql.viewerState(String(row.post), String(row.viewer), String(row.author)),
      ]);
      mismatches.push(...differences(rest, direct, `${row.post}.viewer`));
      // A row that exists in `likes` must read as liked on both sides, or the
      // comparison is agreeing on the wrong answer.
      if (!rest.liked) mismatches.push(`${row.post}: PostgREST says not liked`);
      if (!direct.liked) mismatches.push(`${row.post}: PostgreSQL says not liked`);
    }
    expect(mismatches, mismatches.join("\n")).toEqual([]);
  }, 300_000);
});

describe.skipIf(enabled)("post page: PostgREST vs PostgreSQL, same database", () => {
  it("is skipped without both connections", () => {
    const missing = [
      !supabaseUrl && "NEXT_PUBLIC_SUPABASE_URL",
      !serviceKey && "SUPABASE_SERVICE_ROLE_KEY",
      !directUrl && "SUPABASE_DIRECT_URL (the pooled Supabase Postgres connection)",
    ].filter(Boolean);
    console.info(`[postPage parity] not run. Missing: ${missing.join(", ")}`);
    expect(missing.length).toBeGreaterThan(0);
  });
});
