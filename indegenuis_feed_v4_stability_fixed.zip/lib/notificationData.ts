import { notificationsRepository } from "@/lib/db/readAdapter";

export {
  groupByDate,
  sectionsFromNotifications,
} from "@/lib/notificationShape";
export type {
  NotificationData,
  NotificationSection,
} from "@/lib/notificationShape";

import type { NotificationData } from "@/lib/notificationShape";

// The loader still takes a Supabase client on the un-migrated path.
type NotificationsQueryClient = {
  from: (table: string) => any;
};

export interface NotificationRowsResult {
  rows: NotificationData[];
  error: string | null;
}

/**
 * The one notification read query. The bell dropdown previously ran its own
 * `select("*")` without the actor/post joins, which is why its fallback copy could
 * only say "Someone started following you" while the page said who.
 */
export async function fetchNotificationRows(
  supabase: NotificationsQueryClient,
  userId: string,
  limit = 50,
  mutedTypes: string[] = []
): Promise<NotificationRowsResult> {
  // Muting is applied in the query rather than at insert time, so one rule
  // covers both surfaces and turning a group back on restores its history.
  // Dismissal is a soft delete, so it is filtered rather than being gone.
  let raw: Array<Record<string, unknown>> = [];
  let error: { message: string } | null = null;
  try {
    raw = (await notificationsRepository(supabase as never).list(
      userId,
      limit,
      mutedTypes
    )) as unknown as Array<Record<string, unknown>>;
  } catch (failure) {
    // The caller distinguishes "no notifications" from "we could not ask", so
    // a failure arrives as a message rather than as an empty list.
    error = {
      message: failure instanceof Error ? failure.message : String(failure),
    };
  }

  const rows = raw.flatMap((notification) => {
    const rawActor = notification.actor as
      | NotificationData["actor"]
      | NotificationData["actor"][]
      | null;
    const rawPost = notification.post as
      | { title: string; slug: string; content_kind: string | null }
      | { title: string; slug: string; content_kind: string | null }[]
      | null;
    const actor = Array.isArray(rawActor) ? rawActor[0] ?? null : rawActor;
    const post = Array.isArray(rawPost) ? rawPost[0] ?? null : rawPost;

    return [{
      id: notification.id as string,
      type: notification.type as string,
      read: notification.read as boolean,
      created_at: notification.created_at as string,
      message: (notification.message as string | null) ?? null,
      link: (notification.link as string | null) ?? null,
      post_id: (notification.post_id as string | null) ?? null,
      actor,
      actor_username: actor?.username ?? null,
      post_title: post?.title ?? null,
      post_slug: post?.slug ?? null,
      post_content_kind: post?.content_kind ?? null,
    }];
  });

  return { rows, error: error?.message ?? null };
}

export interface UnreadCountResult {
  count: number | null;
  error: string | null;
}

/**
 * The true number of unread notifications.
 *
 * The bell used to derive its badge from the ten rows it had fetched, so the count
 * was capped at ten and — worse — simply wrong: someone with forty unread items
 * saw "3" whenever only three of the newest ten happened to be unread. This is a
 * `head` count, so it costs a round trip but transfers no rows.
 *
 * `count` is null when the query fails, so a caller can tell "no unread" apart from
 * "we do not know" and leave the previous badge alone rather than clearing it.
 */
export async function fetchUnreadCount(
  supabase: NotificationsQueryClient,
  userId: string,
  mutedTypes: string[] = []
): Promise<UnreadCountResult> {
  // Must match fetchNotificationRows exactly, or the badge counts
  // notifications the inbox will not show. Both go through one repository, so
  // the two filter sets cannot drift apart.
  try {
    return {
      count: await notificationsRepository(supabase as never).unreadCount(
        userId,
        mutedTypes
      ),
      error: null,
    };
  } catch (failure) {
    // null, not zero: the caller leaves the previous badge alone rather than
    // clearing it, because "we do not know" is not "no unread".
    return {
      count: null,
      error: failure instanceof Error ? failure.message : String(failure),
    };
  }
}
