import "server-only";

/**
 * Everything the post page reads besides the post itself.
 *
 * ## Why this exists
 *
 * The page made roughly seventeen PostgREST round trips, one of which
 * (`getPostBySlug`) already went through `lib/db`. The other sixteen went to
 * Supabase's gateway, so a gateway failure left the page hanging even though
 * the core post had been fetched.
 *
 * These read the same production database, through PostgreSQL directly rather
 * than through PostgREST. That is the whole point of this stage: no second
 * database, no staleness, no split brain, and every migrated read becomes
 * portable to Neon later by changing a connection string.
 *
 * ## Bounded, not one-for-one
 *
 * Fifteen PostgREST calls become four statements. The counts are one row of
 * scalar subqueries; the child collections are one row of `jsonb_agg`s; the
 * neighbours are one `UNION ALL`. Reproducing fifteen separate round trips in
 * SQL would move the failure and keep the latency.
 *
 * ## What this does not do
 *
 * It does not protect against the database being down. It removes PostgREST
 * from the path for these reads, which is a gateway-shaped failure, and that
 * is all. Removing the database as a single point of failure is the Neon
 * cutover, and this is not it.
 */

import type { SupabaseClient } from "@supabase/supabase-js";

import {
  profileVisibleSql,
  visibleProfileJoin,
} from "@/lib/db/profileVisibility";

import type { SqlExecutor } from "@/lib/db/postgres/executor";

// ── Shapes ───────────────────────────────────────────────────────────

export interface PostPageCounts {
  likeCount: number;
  bookmarkCount: number;
  commentCount: number;
}

export interface PostReferenceRow {
  id: string;
  post_id: string;
  display_order: number | null;
  title: string | null;
  source: string | null;
  authors: string | null;
  url: string | null;
  doi: string | null;
  raw: string | null;
  year: number | null;
  ref_type: string | null;
}

export interface NeighbourPost {
  id: string;
  title: string | null;
  slug: string;
}

export interface RelatedPost {
  id: string;
  title: string | null;
  slug: string;
  content_kind: string | null;
  published_at: string | null;
  created_at: string;
  cover_image_url: string | null;
  profiles: { full_name: string | null; username: string } | null;
}

export interface PostPageCollections {
  references: PostReferenceRow[];
}

export interface PostPageViewerState {
  liked: boolean;
  bookmarked: boolean;
  following: boolean;
}

export interface PostPageRepository {
  counts(postId: string): Promise<PostPageCounts>;
  collections(
    postId: string,
    _viewerId?: string | null
  ): Promise<PostPageCollections>;
  related(
    postId: string,
    tags: readonly string[],
    limit: number,
    viewerId: string | null
  ): Promise<RelatedPost[]>;
  neighbours(
    postId: string,
    publishedAt: string
  ): Promise<{ previous: NeighbourPost | null; next: NeighbourPost | null }>;
  /** Authenticated only. The viewer id comes from the server, never from the
   *  request body: these are the four booleans that decide whether the page
   *  shows "liked" and "following", and a caller-supplied id would let anybody
   *  read anybody's. */
  viewerState(
    postId: string,
    viewerId: string,
    authorId: string | null
  ): Promise<PostPageViewerState>;
  readonly backend: "supabase" | "postgres";
}

// ── Supabase (the existing behaviour, gathered in one place) ─────────

/**
 * A result, or an error. Never an absence standing in for one.
 *
 * Every method on the Supabase side of this repository used to destructure
 * `{ data }` or read `.count ?? 0` and drop `.error`. A post page served by a
 * slow PostgREST therefore rendered zero comments, zero likes, no co-authors
 * and no references, and reported success.
 *
 * Live parity is what found it: the PostgreSQL side counted two comments and
 * the PostgREST side counted none, because its request had failed and nobody
 * looked. A comparison cannot tell "no rows" from "no answer" if one side
 * refuses to say which it had.
 */
function fail(error: unknown, label: string): never {
  const source = error as { message?: unknown };
  throw new Error(
    `${label}: ${typeof source.message === "string" ? source.message : "database error"}`
  );
}

function rows<T>(result: { data?: unknown; error?: unknown }, label: string): T[] {
  if (result.error) fail(result.error, label);
  return (result.data ?? []) as T[];
}

/** `null` stays a valid answer here: it means no row, not no answer. */
function maybeRow<T>(
  result: { data?: unknown; error?: unknown },
  label: string
): T | null {
  if (result.error) fail(result.error, label);
  return (result.data ?? null) as T | null;
}

function count(
  result: { count?: number | null; error?: unknown },
  label: string
): number {
  if (result.error) fail(result.error, label);
  return result.count ?? 0;
}

export function createSupabasePostPageRepository(
  supabase: SupabaseClient
): PostPageRepository {
  return {
    backend: "supabase",

    async counts(postId) {
      const [likes, bookmarks, comments] = await Promise.all([
        supabase.from("likes").select("*", { count: "exact", head: true }).eq("post_id", postId),
        supabase.from("bookmarks").select("*", { count: "exact", head: true }).eq("post_id", postId),
        supabase.from("comments").select("id", { count: "exact", head: true }).eq("post_id", postId),
      ]);

      return {
        likeCount: count(likes, "like count"),
        bookmarkCount: count(bookmarks, "bookmark count"),
        commentCount: count(comments, "comment count"),
      };
    },

      // The viewer is unused on this side: the request client carries the
      // session, so the profiles policy is applied by the database.
    async collections(postId, _viewerId) {
      const references = await supabase
        .from("post_references")
        .select("*")
        .eq("post_id", postId)
        .order("display_order", { ascending: true });

      return {
        references: rows<PostReferenceRow>(references, "post references"),
      };
    },

      // The viewer is unused on this side: the request client carries the
      // session, so the profiles policy is applied by the database.
    async related(postId, tags, limit, _viewerId) {
      if (tags.length === 0) return [];
      const result = await supabase
        .from("posts")
        .select(
          "id, title, slug, content_kind, published_at, created_at, cover_image_url, profiles!posts_author_id_fkey (full_name, username)"
        )
        .eq("status", "published")
        .neq("id", postId)
        .overlaps("tags", tags as string[])
        .order("published_at", { ascending: false })
        .limit(limit);

      return rows<Record<string, unknown>>(result, "related posts").map((row) => ({
        ...(row as unknown as RelatedPost),
        profiles: (Array.isArray(row.profiles)
          ? (row.profiles[0] ?? null)
          : (row.profiles ?? null)) as RelatedPost["profiles"],
      }));
    },

    async neighbours(postId, publishedAt) {
      const [previous, next] = await Promise.all([
        supabase
          .from("posts")
          .select("id, title, slug")
          .eq("status", "published")
          .neq("id", postId)
          .lt("published_at", publishedAt)
          .order("published_at", { ascending: false })
          .limit(1)
          .maybeSingle(),
        supabase
          .from("posts")
          .select("id, title, slug")
          .eq("status", "published")
          .neq("id", postId)
          .gt("published_at", publishedAt)
          .order("published_at", { ascending: true })
          .limit(1)
          .maybeSingle(),
      ]);

      return {
        previous: maybeRow<NeighbourPost>(previous, "previous post"),
        next: maybeRow<NeighbourPost>(next, "next post"),
      };
    },

    async viewerState(postId, viewerId, authorId) {
      const [like, bookmark, follow] = await Promise.all([
        supabase
          .from("likes")
          .select("user_id")
          .eq("post_id", postId)
          .eq("user_id", viewerId)
          .maybeSingle(),
        supabase
          .from("bookmarks")
          .select("user_id")
          .eq("post_id", postId)
          .eq("user_id", viewerId)
          .maybeSingle(),
        authorId
          ? supabase
              .from("follows")
              .select("follower_id")
              .eq("follower_id", viewerId)
              .eq("following_id", authorId)
              .maybeSingle()
          : Promise.resolve({ data: null }),
      ]);

      // A failed lookup is not "not liked". Rendering an empty heart
      // because the request failed invites the reader to like it again.
      return {
        liked: maybeRow(like, "viewer like") !== null,
        bookmarked: maybeRow(bookmark, "viewer bookmark") !== null,
        following: maybeRow(follow, "viewer follow") !== null,
      };
    },
  };
}

// ── PostgreSQL ───────────────────────────────────────────────────────

/**
 * Where the viewer sits in each statement's parameter list.
 *
 * These three projections read through the *request* client on the PostgREST
 * side, so the `profiles` policy applied to every one of them: a co-author, a
 * related post's author or a parent post's author who is suspended or whose
 * profile is not public came back as null rather than as a name. A direct
 * connection has no policy and the join has to carry the rule.
 *
 * Each is a JOIN condition rather than a WHERE clause, which is the difference
 * between hiding a name and deleting a published post from the page.
 */
const RELATED_VIEWER = "$4";

/**
 * Counts, as one row of scalar subqueries.
 *
 * PostgREST spends a round trip per `count: exact, head: true`. Postgres does
 * not need three connections to count three things.
 */
const COUNTS_SQL = `
  select
    (select count(*) from public.likes where post_id = $1::uuid) as like_count,
    (select count(*) from public.bookmarks where post_id = $1::uuid) as bookmark_count,
    (select count(*) from public.comments where post_id = $1::uuid) as comment_count
`;

/**
 * The publication references, as one jsonb aggregate.
 *
 * `jsonb_agg` rather than a join: five collections in one result set would be
 * a cross product, and the page wants five lists, not one denormalised table.
 * Each aggregate carries its own ORDER BY, which is where PostgREST's
 * `.order()` went. `coalesce` to `[]` because `jsonb_agg` over no rows is NULL
 * and every caller here expects an array it can map.
 */
const COLLECTIONS_SQL = `
  select coalesce((
    select jsonb_agg(to_jsonb(r) order by r.display_order asc nulls last)
    from public.post_references as r
    where r.post_id = $1::uuid
  ), '[]'::jsonb) as references
`;

/**
 * Related posts, by tag overlap.
 *
 * The tag array arrives as jsonb and is converted in SQL, for the reason
 * lib/db/postWrites.ts documents: `fetch_types: false` means the driver
 * cannot serialise an array parameter, and `$n::jsonb` makes it double-encode
 * an already-serialised one. `$n::text::jsonb` is the shape that survives.
 */
const RELATED_SQL = `
  select
    p.id, p.title, p.slug, p.content_kind,
    p.published_at, p.created_at, p.cover_image_url,
    case when author.id is null then null else jsonb_build_object(
      'full_name', author.full_name,
      'username', author.username
    ) end as profiles
  from public.posts as p
  ${visibleProfileJoin("author", "p.author_id", RELATED_VIEWER)}
  where p.status = 'published'
    and p.id <> $1::uuid
    and p.tags && ARRAY(select jsonb_array_elements_text($2::text::jsonb))
  order by p.published_at desc nulls last
  limit $3::int
`;

/**
 * The previous and next published post, in one statement.
 *
 * Two `maybeSingle()` round trips become one `UNION ALL`. The discriminator is
 * a literal rather than a computed column so neither branch can be mistaken
 * for the other when one of them returns nothing.
 */
const NEIGHBOURS_SQL = `
  (
    select 'previous' as direction, p.id, p.title, p.slug
    from public.posts as p
    where p.status = 'published' and p.id <> $1::uuid
      and p.published_at < $2::timestamptz
    order by p.published_at desc
    limit 1
  )
  union all
  (
    select 'next' as direction, p.id, p.title, p.slug
    from public.posts as p
    where p.status = 'published' and p.id <> $1::uuid
      and p.published_at > $2::timestamptz
    order by p.published_at asc
    limit 1
  )
`;

/**
 * The viewer's relationship to this post and its author.
 *
 * Four `maybeSingle()` lookups become four `exists` in one row. The viewer id
 * is a parameter the server resolved; there is no `auth.uid()` here and there
 * cannot be, because a direct connection has none.
 */
const VIEWER_STATE_SQL = `
  select
    exists(select 1 from public.likes
            where post_id = $1::uuid and user_id = $2::uuid) as liked,
    exists(select 1 from public.bookmarks
            where post_id = $1::uuid and user_id = $2::uuid) as bookmarked,
    case when $3::uuid is null then false else exists(
      select 1 from public.follows
        where follower_id = $2::uuid and following_id = $3::uuid) end as following
`;

function toNumber(value: unknown): number {
  const parsed = typeof value === "number" ? value : Number(value);
  return Number.isFinite(parsed) ? parsed : 0;
}

function toIso(value: unknown): string | null {
  if (value === null || value === undefined) return null;
  return value instanceof Date ? value.toISOString() : String(value);
}

/** jsonb comes back parsed from postgres.js; a `json` column or an untyped
 *  driver would hand over a string. Both are accepted. */
function toArray<T>(value: unknown): T[] {
  if (Array.isArray(value)) return value as T[];
  if (typeof value === "string") {
    try {
      const parsed: unknown = JSON.parse(value);
      return Array.isArray(parsed) ? (parsed as T[]) : [];
    } catch {
      return [];
    }
  }
  return [];
}

export function createPostgresPostPageRepository(
  executor: SqlExecutor
): PostPageRepository {
  return {
    backend: "postgres",

    async counts(postId) {
      const [row] = await executor.query<Record<string, unknown>>(COUNTS_SQL, [postId]);
      return {
        likeCount: toNumber(row?.like_count),
        bookmarkCount: toNumber(row?.bookmark_count),
        commentCount: toNumber(row?.comment_count),
      };
    },

    async collections(postId, _viewerId) {
      const [row] = await executor.query<Record<string, unknown>>(COLLECTIONS_SQL, [postId]);
      return { references: toArray<PostReferenceRow>(row?.references) };
    },

    async related(postId, tags, limit, viewerId) {
      if (tags.length === 0) return [];
      const rows = await executor.query<Record<string, unknown>>(RELATED_SQL, [
        postId,
        JSON.stringify(tags),
        limit,
        viewerId,
      ]);

      return rows.map((row) => ({
        id: String(row.id),
        title: (row.title as string | null) ?? null,
        slug: String(row.slug),
        content_kind: (row.content_kind as string | null) ?? null,
        published_at: toIso(row.published_at),
        created_at: toIso(row.created_at) ?? "",
        cover_image_url: (row.cover_image_url as string | null) ?? null,
        profiles: (row.profiles ?? null) as RelatedPost["profiles"],
      }));
    },

    async neighbours(postId, publishedAt) {
      const rows = await executor.query<Record<string, unknown>>(NEIGHBOURS_SQL, [
        postId,
        publishedAt,
      ]);

      const pick = (direction: string): NeighbourPost | null => {
        const row = rows.find((entry) => entry.direction === direction);
        if (!row) return null;
        return {
          id: String(row.id),
          title: (row.title as string | null) ?? null,
          slug: String(row.slug),
        };
      };

      return { previous: pick("previous"), next: pick("next") };
    },

    async viewerState(postId, viewerId, authorId) {
      const [row] = await executor.query<Record<string, unknown>>(VIEWER_STATE_SQL, [
        postId,
        viewerId,
        authorId,
      ]);

      return {
        liked: row?.liked === true,
        bookmarked: row?.bookmarked === true,
        following: row?.following === true,
      };
    },
  };
}
