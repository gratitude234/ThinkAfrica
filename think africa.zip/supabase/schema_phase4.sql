-- ============================================================
-- ThinkAfrica Phase 4 Database Schema
-- Run this in the Supabase SQL Editor after schema_phase3.sql
-- ============================================================

-- ============================================================
-- TABLES
-- ============================================================

create table if not exists public.fellowships (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  description text,
  sponsor_name text,
  sponsor_logo_url text,
  amount text,
  eligibility text,
  deadline timestamptz,
  application_url text,
  opportunity_type text not null default 'fellowship' check (opportunity_type in ('internship', 'research', 'fellowship', 'job')),
  skills text[] default '{}',
  location text,
  featured boolean not null default false,
  status text not null default 'open' check (status in ('open', 'closed')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.fellowship_applications (
  id uuid primary key default gen_random_uuid(),
  fellowship_id uuid not null references public.fellowships(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  cover_letter text,
  status text not null default 'pending' check (status in ('pending', 'shortlisted', 'accepted', 'rejected')),
  applied_at timestamptz not null default now(),
  unique (fellowship_id, user_id)
);

create table if not exists public.institutional_partners (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  type text check (type in ('university', 'ngo', 'government', 'thinktank', 'media')),
  country text,
  logo_url text,
  description text,
  website_url text,
  partnership_since timestamptz not null default now(),
  active boolean not null default true
);

create table if not exists public.talent_profiles (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null unique references public.profiles(id) on delete cascade,
  open_to_opportunities boolean not null default false,
  opportunity_types text[] default '{}',
  cv_url text,
  linkedin_url text,
  skills text[] default '{}',
  visibility text not null default 'public' check (visibility in ('public', 'partners_only', 'private')),
  updated_at timestamptz not null default now()
);

create table if not exists public.talent_inquiries (
  id uuid primary key default gen_random_uuid(),
  talent_id uuid not null references public.talent_profiles(id) on delete cascade,
  sender_id uuid references public.profiles(id) on delete set null,
  organization_name text,
  contact_email text,
  opportunity_type text check (opportunity_type in ('internship', 'research', 'fellowship', 'job')),
  role_title text,
  message text,
  status text not null default 'new' check (status in ('new', 'read', 'archived')),
  read_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.sponsor_placements (
  id uuid primary key default gen_random_uuid(),
  sponsor_name text not null,
  placement_type text not null check (placement_type in ('fellowship', 'webinar', 'leaderboard', 'policy_hub')),
  content text,
  link_url text,
  active boolean not null default true,
  created_at timestamptz not null default now()
);

create table if not exists public.contact_requests (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  organization text not null,
  email text not null,
  message text,
  created_at timestamptz not null default now()
);

-- ============================================================
-- PROFILE COLUMNS
-- ============================================================

alter table public.profiles add column if not exists verified boolean not null default false;
alter table public.profiles add column if not exists verified_type text check (verified_type in ('student', 'researcher', 'faculty', 'institution'));

-- ============================================================
-- INDEXES
-- ============================================================

create index if not exists fellowships_status_idx on public.fellowships(status);
create index if not exists fellowships_deadline_idx on public.fellowships(deadline asc);
create index if not exists fellowships_status_type_deadline_idx on public.fellowships(status, opportunity_type, deadline asc);
create index if not exists fellowships_featured_idx on public.fellowships(featured, status) where featured = true;
create index if not exists fellowships_skills_gin_idx on public.fellowships using gin(skills);
create index if not exists fellowship_applications_fellowship_id_idx on public.fellowship_applications(fellowship_id);
create index if not exists fellowship_applications_user_id_idx on public.fellowship_applications(user_id);
create index if not exists institutional_partners_active_idx on public.institutional_partners(active);
create index if not exists talent_profiles_visibility_idx on public.talent_profiles(visibility);
create index if not exists talent_inquiries_talent_status_created_idx on public.talent_inquiries(talent_id, status, created_at desc);
create index if not exists talent_inquiries_sender_idx on public.talent_inquiries(sender_id, created_at desc) where sender_id is not null;
create index if not exists sponsor_placements_type_active_idx on public.sponsor_placements(placement_type, active);

-- ============================================================
-- ROW LEVEL SECURITY
-- ============================================================

alter table public.fellowships enable row level security;
alter table public.fellowship_applications enable row level security;
alter table public.institutional_partners enable row level security;
alter table public.talent_profiles enable row level security;
alter table public.talent_inquiries enable row level security;
alter table public.sponsor_placements enable row level security;
alter table public.contact_requests enable row level security;

-- fellowships
drop policy if exists "Fellowships are viewable by everyone" on public.fellowships;
create policy "Fellowships are viewable by everyone"
  on public.fellowships for select using (true);

drop policy if exists "Admins can insert fellowships" on public.fellowships;
create policy "Admins can insert fellowships"
  on public.fellowships for insert
  with check (public.is_admin());

drop policy if exists "Admins can update fellowships" on public.fellowships;
create policy "Admins can update fellowships"
  on public.fellowships for update
  using (public.is_admin())
  with check (public.is_admin());

-- fellowship_applications
drop policy if exists "Users can read their own applications" on public.fellowship_applications;
create policy "Users can read their own applications"
  on public.fellowship_applications for select
  using (auth.uid() = user_id);

drop policy if exists "Admins can read all applications" on public.fellowship_applications;
create policy "Admins can read all applications"
  on public.fellowship_applications for select
  using (public.is_admin());

drop policy if exists "Authenticated users can apply" on public.fellowship_applications;
create policy "Authenticated users can apply"
  on public.fellowship_applications for insert
  with check (auth.role() = 'authenticated' and auth.uid() = user_id);

drop policy if exists "Admins can update application status" on public.fellowship_applications;
create policy "Admins can update application status"
  on public.fellowship_applications for update
  using (public.is_admin())
  with check (public.is_admin());

-- institutional_partners
drop policy if exists "Partners are viewable by everyone" on public.institutional_partners;
create policy "Partners are viewable by everyone"
  on public.institutional_partners for select using (true);

drop policy if exists "Admins can manage partners" on public.institutional_partners;
create policy "Admins can manage partners"
  on public.institutional_partners for all
  using (public.is_admin())
  with check (public.is_admin());

-- talent_profiles
drop policy if exists "Public talent profiles visible to all" on public.talent_profiles;
create policy "Public talent profiles visible to all"
  on public.talent_profiles for select
  using (visibility = 'public' or auth.uid() = user_id);

drop policy if exists "partners_only visible to authenticated" on public.talent_profiles;
create policy "partners_only visible to authenticated"
  on public.talent_profiles for select
  using (visibility = 'partners_only' and auth.role() = 'authenticated');

drop policy if exists "Users can manage their own talent profile" on public.talent_profiles;
create policy "Users can manage their own talent profile"
  on public.talent_profiles for all
  using (auth.uid() = user_id)
  with check (auth.uid() = user_id);

-- talent_inquiries
drop policy if exists "Anyone authenticated can send inquiries" on public.talent_inquiries;
create policy "Anyone authenticated can send inquiries"
  on public.talent_inquiries for insert
  with check (
    auth.role() = 'authenticated'
    and (sender_id is null or sender_id = auth.uid())
  );

drop policy if exists "Talent can read their own inquiries" on public.talent_inquiries;
create policy "Talent can read their own inquiries"
  on public.talent_inquiries for select
  using (
    exists (select 1 from public.talent_profiles where id = talent_id and user_id = auth.uid())
  );

drop policy if exists "Talent can update their own inquiries" on public.talent_inquiries;
create policy "Talent can update their own inquiries"
  on public.talent_inquiries for update
  using (
    exists (select 1 from public.talent_profiles where id = talent_id and user_id = auth.uid())
  )
  with check (
    exists (select 1 from public.talent_profiles where id = talent_id and user_id = auth.uid())
  );

-- sponsor_placements
drop policy if exists "Sponsor placements viewable by everyone" on public.sponsor_placements;
create policy "Sponsor placements viewable by everyone"
  on public.sponsor_placements for select using (true);

drop policy if exists "Admins can manage sponsor placements" on public.sponsor_placements;
create policy "Admins can manage sponsor placements"
  on public.sponsor_placements for all
  using (public.is_admin())
  with check (public.is_admin());

-- contact_requests
drop policy if exists "Anyone can submit contact requests" on public.contact_requests;
create policy "Anyone can submit contact requests"
  on public.contact_requests for insert with check (true);

drop policy if exists "Admins can read contact requests" on public.contact_requests;
create policy "Admins can read contact requests"
  on public.contact_requests for select
  using (public.is_admin());
