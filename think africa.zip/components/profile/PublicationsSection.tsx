"use client";

import Link from "next/link";
import { useState } from "react";
import { formatDate } from "@/lib/utils";

interface PublicationPost {
  id: string;
  title: string;
  slug: string;
  excerpt: string | null;
  type: string;
  created_at: string;
  published_at: string | null;
  view_count?: number | null;
}

interface PublicationsSectionProps {
  posts: PublicationPost[];
  fullName: string;
}

const GROUP_CONFIG = [
  { type: "research", label: "Research" },
  { type: "policy_brief", label: "Policy Briefs" },
  { type: "essay", label: "Essays" },
  { type: "blog", label: "Quick Takes" },
] as const;

export default function PublicationsSection({
  posts,
  fullName,
}: PublicationsSectionProps) {
  const [expandedTypes, setExpandedTypes] = useState<Record<string, boolean>>(
    {}
  );

  if (posts.length === 0) {
    return (
      <section className="rounded-2xl border border-gray-200 bg-white p-8 text-center">
        <h2 className="text-lg font-semibold text-gray-900">Publications</h2>
        <p className="mt-2 text-sm text-gray-500">
          {fullName} hasn&apos;t published anything yet.
        </p>
      </section>
    );
  }

  return (
    <section className="space-y-6">
      <div>
        <h2 className="text-lg font-semibold text-gray-900">Publications</h2>
        <p className="mt-1 text-sm text-gray-500">
          Organized by format so the strongest signal is easy to scan.
        </p>
      </div>

      {GROUP_CONFIG.map(({ type, label }) => {
        const groupPosts = posts.filter((post) => post.type === type);
        if (groupPosts.length === 0) return null;

        const expanded = expandedTypes[type] ?? false;
        const visiblePosts = expanded ? groupPosts : groupPosts.slice(0, 5);

        return (
          <div
            key={type}
            className="rounded-2xl border border-gray-200 bg-white p-5"
          >
            <div className="mb-4 flex items-center justify-between gap-3">
              <h3 className="text-base font-semibold text-gray-900">
                {label} · {groupPosts.length}
              </h3>
              {groupPosts.length > 5 ? (
                <button
                  type="button"
                  onClick={() =>
                    setExpandedTypes((current) => ({
                      ...current,
                      [type]: !expanded,
                    }))
                  }
                  className="text-sm font-medium text-emerald-brand transition-colors hover:text-emerald-700"
                >
                  {expanded ? "Show less" : `See all (${groupPosts.length}) →`}
                </button>
              ) : null}
            </div>

            <div className="divide-y divide-gray-100">
              {visiblePosts.map((post) => {
                const publishedDate = post.published_at ?? post.created_at;
                return (
                  <Link
                    key={post.id}
                    href={`/post/${post.slug}`}
                    className="flex flex-col gap-3 py-4 first:pt-0 last:pb-0 transition-colors hover:text-emerald-brand md:flex-row md:items-start md:justify-between"
                  >
                    <div className="min-w-0">
                      <h4 className="truncate text-sm font-semibold text-gray-900">
                        {post.title}
                      </h4>
                      {post.excerpt ? (
                        <p className="mt-1 line-clamp-1 text-sm text-gray-500">
                          {post.excerpt}
                        </p>
                      ) : null}
                    </div>
                    <div className="shrink-0 text-sm text-gray-400 md:text-right">
                      <p>{formatDate(publishedDate)}</p>
                      <p>{(post.view_count ?? 0).toLocaleString()} views</p>
                    </div>
                  </Link>
                );
              })}
            </div>
          </div>
        );
      })}
    </section>
  );
}
