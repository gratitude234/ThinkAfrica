import Link from "next/link";
import type { PostCardData } from "./PostCard";

function getTopTopic(posts: PostCardData[]) {
  const counts = new Map<string, number>();
  for (const post of posts) {
    for (const tag of post.tags ?? []) {
      counts.set(tag, (counts.get(tag) ?? 0) + 1);
    }
  }

  const topTag = Array.from(counts.entries()).sort((a, b) => b[1] - a[1])[0]?.[0];
  if (!topTag) return null;

  return {
    tag: topTag,
    posts: posts.filter((post) => (post.tags ?? []).includes(topTag)).slice(0, 2),
  };
}

export default function TopicInterlude({ posts }: { posts: PostCardData[] }) {
  const topic = getTopTopic(posts);

  if (!topic) return null;

  return (
    <div className="rounded-2xl border border-gray-200 bg-gray-50 p-5">
      <p className="text-xs font-semibold uppercase tracking-wide text-gray-400">
        Topic spotlight
      </p>
      <Link
        href={`/topics/${encodeURIComponent(topic.tag)}`}
        className="mt-2 inline-block text-lg font-semibold text-gray-900 hover:text-emerald-brand"
      >
        {topic.tag}
      </Link>
      <div className="mt-3 space-y-2">
        {topic.posts.map((post) => (
          <Link
            key={post.id}
            href={`/post/${post.slug}`}
            className="block rounded-xl bg-white px-4 py-3 hover:bg-gray-100"
          >
            <p className="line-clamp-2 text-sm font-medium text-gray-800">
              {post.title}
            </p>
          </Link>
        ))}
      </div>
    </div>
  );
}
