"use client";

import Link from "next/link";
import Image from "next/image";
import { usePathname } from "next/navigation";
import type { User } from "@supabase/supabase-js";
import NavUserMenu from "./NavUserMenu";
import MobileNav from "./MobileNav";
import NotificationBell from "@/components/ui/NotificationBell";

interface NavClientProps {
  user: User | null;
  profile: { username: string; full_name: string | null; points?: number } | null;
  isAdmin: boolean;
  onOpenSearch: () => void;
}

function navItemClass(isActive: boolean) {
  return `rounded-lg px-4 py-2 text-sm transition-colors ${
    isActive
      ? "font-semibold text-emerald-brand"
      : "text-gray-600 hover:bg-gray-50 hover:text-emerald-brand"
  }`;
}

export default function NavClient({
  user,
  profile,
  isAdmin,
  onOpenSearch,
}: NavClientProps) {
  const pathname = usePathname();
  const profileHref = profile?.username ? `/${profile.username}` : null;
  const isFeedActive = pathname === "/";
  const isWriteActive = pathname.startsWith("/write");
  const isProfileActive = profileHref
    ? pathname === profileHref || pathname.startsWith(`${profileHref}/`)
    : false;
  const isSearchActive = pathname.startsWith("/search");

  return (
    <nav className="sticky top-0 z-50 border-b border-gray-200 bg-white">
      <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
        <div className="flex h-16 items-center justify-between">
          <Link href="/" className="flex flex-shrink-0 items-center gap-2">
            <Image
              src="/logo.png"
              alt="ThinkAfrika"
              width={160}
              height={48}
              priority
              className="h-16 w-auto"
            />
          </Link>

          <div className="hidden items-center gap-1 md:flex">
            <Link href="/" className={navItemClass(isFeedActive)}>
              Feed
            </Link>
            <Link href="/write" className={navItemClass(isWriteActive)}>
              Write
            </Link>
            {profileHref ? (
              <Link href={profileHref} className={navItemClass(isProfileActive)}>
                Profile
              </Link>
            ) : null}
            <button
              type="button"
              onClick={onOpenSearch}
              className={navItemClass(isSearchActive)}
            >
              Search
            </button>
          </div>

          <div className="flex items-center gap-2">
            {user && <NotificationBell userId={user.id} />}
            <NavUserMenu
              user={user}
              profile={profile}
              points={profile?.points ?? 0}
              isAdmin={isAdmin}
            />
            <MobileNav
              user={user}
              profile={profile}
              isAdmin={isAdmin}
              onOpenSearch={onOpenSearch}
            />
          </div>
        </div>
      </div>
    </nav>
  );
}
