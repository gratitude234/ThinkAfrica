"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { assignReviewer } from "./actions";

interface ReviewerOption {
  id: string;
  username: string;
  full_name: string | null;
}

interface Props {
  postId: string;
  round: number;
  reviewers: ReviewerOption[];
  assignments: Array<{
    reviewer_id: string;
    submitted_at: string | null;
    recommendation: string | null;
    reviewer: ReviewerOption | null;
  }>;
}

export default function AssignReviewers({
  postId,
  round,
  reviewers,
  assignments,
}: Props) {
  const router = useRouter();
  const [selectedReviewer, setSelectedReviewer] = useState(reviewers[0]?.id ?? "");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleAssign = async () => {
    if (!selectedReviewer) return;
    setLoading(true);
    setError(null);
    const result = await assignReviewer(postId, selectedReviewer, round);
    setLoading(false);

    if (result.error) {
      setError(result.error);
      return;
    }

    router.refresh();
  };

  return (
    <div className="space-y-3 rounded-xl border border-purple-200 bg-purple-50/50 p-4">
      <div>
        <p className="text-sm font-semibold text-gray-900">Assign reviewers</p>
        <p className="mt-1 text-xs text-gray-500">Round {round}</p>
      </div>

      {reviewers.length > 0 ? (
        <div className="flex items-center gap-2">
          <select
            value={selectedReviewer}
            onChange={(event) => setSelectedReviewer(event.target.value)}
            className="flex-1 rounded-lg border border-purple-200 bg-white px-3 py-2 text-sm focus:border-transparent focus:outline-none focus:ring-2 focus:ring-purple-300"
          >
            {reviewers.map((reviewer) => (
              <option key={reviewer.id} value={reviewer.id}>
                {reviewer.full_name ?? reviewer.username}
              </option>
            ))}
          </select>
          <button
            type="button"
            onClick={handleAssign}
            disabled={loading}
            className="rounded-lg bg-purple-600 px-3 py-2 text-sm font-medium text-white disabled:opacity-50"
          >
            {loading ? "Assigning..." : "Assign"}
          </button>
        </div>
      ) : (
        <p className="text-sm text-gray-500">No reviewers available.</p>
      )}

      {assignments.length > 0 ? (
        <div className="space-y-2">
          {assignments.map((assignment) => (
            <div
              key={assignment.reviewer_id}
              className="flex items-center justify-between rounded-lg bg-white px-3 py-2 text-sm"
            >
              <span className="font-medium text-gray-800">
                {assignment.reviewer?.full_name ?? assignment.reviewer?.username}
              </span>
              <span
                className={`text-xs font-medium ${
                  assignment.submitted_at ? "text-emerald-700" : "text-amber-700"
                }`}
              >
                {assignment.submitted_at
                  ? assignment.recommendation ?? "Submitted"
                  : "Awaiting review"}
              </span>
            </div>
          ))}
        </div>
      ) : null}

      {error ? <p className="text-xs text-red-600">{error}</p> : null}
    </div>
  );
}
