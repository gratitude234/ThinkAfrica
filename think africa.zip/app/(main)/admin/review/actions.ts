"use server";

import { revalidatePath } from "next/cache";
import { createClient } from "@/lib/supabase/server";
import { canPublish } from "@/lib/roles";
import { resolveReviewCompletion } from "@/lib/reviewWorkflow";

async function requireEditorAccess() {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) {
    return { supabase, error: "You must be signed in." };
  }

  const { data: profile } = await supabase
    .from("profiles")
    .select("role")
    .eq("id", user.id)
    .single();

  const isBootstrapAdmin = user.email === process.env.ADMIN_EMAIL;
  const hasEditorialRole =
    profile?.role === "admin" ||
    profile?.role === "editor" ||
    (profile?.role ? canPublish(profile.role) : false);

  if (!isBootstrapAdmin && !hasEditorialRole) {
    return { supabase, error: "You do not have permission to review posts." };
  }

  return { supabase, error: null };
}

export async function approvePost(postId: string) {
  const { supabase, error: accessError } = await requireEditorAccess();
  if (accessError) return { error: accessError };

  const { data: post } = await supabase
    .from("posts")
    .select("author_id, slug, title")
    .eq("id", postId)
    .single();

  const { error } = await supabase
    .from("posts")
    .update({ status: "published", published_at: new Date().toISOString() })
    .eq("id", postId);

  if (error) return { error: error.message };

  if (post) {
    await supabase.from("notifications").insert({
      user_id: post.author_id,
      type: "post_published",
      message: `Your post "${post.title}" has been published.`,
      link: `/post/${post.slug}`,
      post_id: postId,
      read: false,
    });
  }

  revalidatePath("/admin/review");
  revalidatePath("/dashboard");
  return { error: null };
}

export async function rejectPost(postId: string, reason?: string) {
  const { supabase, error: accessError } = await requireEditorAccess();
  if (accessError) return { error: accessError };

  const { data: post } = await supabase
    .from("posts")
    .select("author_id, title")
    .eq("id", postId)
    .single();

  const { error } = await supabase
    .from("posts")
    .update({ status: "rejected" })
    .eq("id", postId);

  if (error) return { error: error.message };

  if (post) {
    await supabase.from("notifications").insert({
      user_id: post.author_id,
      type: "post_rejected",
      message: reason?.trim()
        ? `Your post "${post.title}" was not approved: ${reason.trim()}`
        : `Your post "${post.title}" was not approved. Visit your dashboard for details.`,
      link: "/dashboard",
      post_id: postId,
      read: false,
    });
  }

  revalidatePath("/admin/review");
  return { error: null };
}

export async function assignReviewer(postId: string, reviewerId: string, round: number) {
  const { supabase, error: accessError } = await requireEditorAccess();
  if (accessError) return { error: accessError };

  const [{ data: reviewer }, { data: post }] = await Promise.all([
    supabase.from("profiles").select("role").eq("id", reviewerId).single(),
    supabase.from("posts").select("author_id, title, slug").eq("id", postId).single(),
  ]);

  if (!post || post.author_id === reviewerId) {
    return { error: "You cannot assign the author as a reviewer." };
  }

  if (reviewer?.role !== "reviewer" && reviewer?.role !== "editor" && reviewer?.role !== "admin") {
    return { error: "Selected user cannot review posts." };
  }

  const { error } = await supabase.from("post_reviews").upsert(
    {
      post_id: postId,
      reviewer_id: reviewerId,
      round,
    },
    {
      onConflict: "post_id,reviewer_id,round",
      ignoreDuplicates: true,
    }
  );

  if (error) return { error: error.message };

  await supabase.from("notifications").insert({
    user_id: reviewerId,
    type: "review_assigned",
    message: `You've been assigned to review: ${post.title}`,
    link: `/review/${postId}`,
    post_id: postId,
    read: false,
  });

  revalidatePath("/admin/review");
  revalidatePath("/review");
  return { error: null };
}

export async function checkReviewCompletion(postId: string) {
  const { error } = await requireEditorAccess();
  if (error) return { error };

  const result = await resolveReviewCompletion(postId);
  revalidatePath("/admin/review");
  revalidatePath("/review");
  revalidatePath("/dashboard");
  return { error: result.error };
}
