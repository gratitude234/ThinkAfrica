"use client";

import { useState, useCallback } from "react";
import { createClient } from "@/lib/supabase/client";
import Button from "@/components/ui/Button";
import AvatarUploader from "./AvatarUploader";

const COMMON_INTERESTS = [
  "economics",
  "governance",
  "public policy",
  "climate change",
  "technology",
  "health",
  "education",
  "agriculture",
  "fintech",
  "entrepreneurship",
  "politics",
  "history",
  "philosophy",
  "law",
  "human rights",
  "gender studies",
  "urbanization",
  "security",
  "trade",
  "diaspora",
];

interface Profile {
  id: string;
  username: string;
  full_name: string | null;
  bio: string | null;
  university: string | null;
  field_of_study: string | null;
  avatar_url: string | null;
  interests: string[] | null;
}

const INPUT_STYLES =
  "w-full rounded-xl border border-gray-200 bg-gray-50 px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500";

export default function ProfileForm({ profile }: { profile: Profile }) {
  const [fullName, setFullName] = useState(profile.full_name ?? "");
  const [username, setUsername] = useState(profile.username);
  const [bio, setBio] = useState(profile.bio ?? "");
  const [university, setUniversity] = useState(profile.university ?? "");
  const [fieldOfStudy, setFieldOfStudy] = useState(profile.field_of_study ?? "");
  const [interests, setInterests] = useState<string[]>(profile.interests ?? []);
  const [avatarUrl, setAvatarUrl] = useState(profile.avatar_url);
  const [usernameError, setUsernameError] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);
  const [toast, setToast] = useState<string | null>(null);

  const checkUsername = useCallback(async () => {
    if (username === profile.username) {
      setUsernameError(null);
      return;
    }

    const supabase = createClient();
    const { data } = await supabase
      .from("profiles")
      .select("id")
      .eq("username", username)
      .neq("id", profile.id)
      .single();

    setUsernameError(data ? "Username already taken" : null);
  }, [username, profile.username, profile.id]);

  const toggleInterest = (interest: string) => {
    setInterests((prev) =>
      prev.includes(interest)
        ? prev.filter((item) => item !== interest)
        : [...prev, interest]
    );
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (usernameError) return;

    setSaving(true);
    const supabase = createClient();

    const { error } = await supabase
      .from("profiles")
      .update({
        full_name: fullName,
        username,
        bio,
        university,
        field_of_study: fieldOfStudy,
        interests,
        avatar_url: avatarUrl,
      })
      .eq("id", profile.id);

    setSaving(false);

    if (error) {
      setToast(`Failed to save: ${error.message}`);
      return;
    }

    setToast("Profile saved successfully!");
    setTimeout(() => setToast(null), 3000);
  };

  return (
    <form onSubmit={handleSave} className="max-w-2xl space-y-6">
      {toast ? (
        <div
          className={`rounded-lg border px-4 py-3 text-sm ${
            toast.startsWith("Failed")
              ? "border-red-200 bg-red-50 text-red-700"
              : "border-emerald-200 bg-emerald-50 text-emerald-700"
          }`}
        >
          {toast}
        </div>
      ) : null}

      <div>
        <label className="mb-2 block text-sm font-medium text-gray-700">
          Profile photo
        </label>
        <AvatarUploader
          userId={profile.id}
          currentUrl={avatarUrl}
          fullName={fullName}
          onUpload={setAvatarUrl}
        />
      </div>

      <div>
        <label className="mb-1 block text-sm font-medium text-gray-700">
          Full name
        </label>
        <input
          type="text"
          value={fullName}
          onChange={(e) => setFullName(e.target.value)}
          className={INPUT_STYLES}
        />
      </div>

      <div>
        <label className="mb-1 block text-sm font-medium text-gray-700">
          Username
        </label>
        <input
          type="text"
          value={username}
          onChange={(e) =>
            setUsername(e.target.value.toLowerCase().replace(/\s+/g, ""))
          }
          onBlur={checkUsername}
          className={`${INPUT_STYLES} ${usernameError ? "border-red-400" : ""}`}
        />
        {usernameError ? (
          <p className="mt-1 text-xs text-red-500">{usernameError}</p>
        ) : null}
      </div>

      <div>
        <label className="mb-1 block text-sm font-medium text-gray-700">
          University
        </label>
        <input
          type="text"
          value={university}
          onChange={(e) => setUniversity(e.target.value)}
          placeholder="e.g. University of Lagos"
          className={INPUT_STYLES}
        />
      </div>

      <div>
        <label className="mb-1 block text-sm font-medium text-gray-700">
          Field of study
        </label>
        <input
          type="text"
          value={fieldOfStudy}
          onChange={(e) => setFieldOfStudy(e.target.value)}
          placeholder="e.g. Computer Science, Law, Economics"
          className={INPUT_STYLES}
        />
      </div>

      <div>
        <label className="mb-1 block text-sm font-medium text-gray-700">
          Bio
        </label>
        <div className="relative">
          <textarea
            value={bio}
            onChange={(e) => setBio(e.target.value)}
            maxLength={300}
            rows={3}
            placeholder="Tell the community about your work and research interests"
            className={`${INPUT_STYLES} resize-none`}
          />
          <span className="absolute bottom-2 right-2 text-xs text-gray-400">
            {bio.length}/300
          </span>
        </div>
      </div>

      <div>
        <label className="mb-2 block text-sm font-medium text-gray-700">
          Topics you write about
          <span className="ml-1 text-xs font-normal text-gray-400">
            (select all that apply)
          </span>
        </label>
        <div className="flex flex-wrap gap-2">
          {COMMON_INTERESTS.map((interest) => (
            <button
              key={interest}
              type="button"
              onClick={() => toggleInterest(interest)}
              className={`rounded-full border px-3 py-1.5 text-sm font-medium capitalize transition-colors ${
                interests.includes(interest)
                  ? "border-emerald-brand bg-emerald-brand text-white"
                  : "border-gray-200 bg-white text-gray-600 hover:border-emerald-brand hover:text-emerald-brand"
              }`}
            >
              {interest}
            </button>
          ))}
        </div>
      </div>

      <div className="flex justify-end pt-2">
        <Button type="submit" loading={saving} disabled={!!usernameError}>
          Save changes
        </Button>
      </div>
    </form>
  );
}
