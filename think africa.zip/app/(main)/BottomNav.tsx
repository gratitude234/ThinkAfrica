"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";

interface BottomNavProps {
  username: string | null;
  onOpenSearch: () => void;
}

export default function BottomNav({ username, onOpenSearch }: BottomNavProps) {
  const pathname = usePathname();
  const isActive = (href: string) =>
    href === "/" ? pathname === "/" : pathname.startsWith(href);
  const profileHref = username ? `/${username}` : "/settings";
  const profileActive = username
    ? pathname === profileHref || pathname.startsWith(`${profileHref}/`)
    : pathname === "/settings" || pathname.startsWith("/settings/");

  return (
    <nav
      className="fixed bottom-0 left-0 right-0 z-50 border-t border-gray-200 bg-white md:hidden"
      style={{ paddingBottom: "env(safe-area-inset-bottom)" }}
    >
      <div className="flex h-16 items-end justify-around px-2">
        <Link
          href="/"
          className={`flex h-full w-full flex-col items-center justify-center gap-1 pb-2 ${
            isActive("/") ? "text-emerald-brand" : "text-gray-500"
          }`}
        >
          <svg
            className="h-5 w-5"
            fill={isActive("/") ? "currentColor" : "none"}
            stroke="currentColor"
            strokeWidth={2}
            viewBox="0 0 24 24"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              d="M3 10.75L12 3l9 7.75V21H14.75v-5.5h-5.5V21H3V10.75z"
            />
          </svg>
          <span className="text-[10px] font-medium">Feed</span>
        </Link>

        <Link
          href="/write"
          className={`flex h-full w-full flex-col items-center justify-center gap-1 pb-2 ${
            isActive("/write") ? "text-emerald-brand" : "text-gray-500"
          }`}
        >
          <div className="-mt-4 flex h-12 w-12 items-center justify-center rounded-full bg-emerald-brand text-white shadow-md">
            <svg
              className="h-6 w-6"
              fill="none"
              stroke="currentColor"
              strokeWidth={2}
              viewBox="0 0 24 24"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                d="M13.5 5.5l5 5M5 19l3.5-.5L18 9l-5-5-9.5 9.5L3 17l2 2z"
              />
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                d="M18.5 3.5v4m-2-2h4"
              />
            </svg>
          </div>
          <span className="pb-2 text-[10px] font-medium">Write</span>
        </Link>

        <Link
          href={profileHref}
          className={`flex h-full w-full flex-col items-center justify-center gap-1 pb-2 ${
            profileActive ? "text-emerald-brand" : "text-gray-500"
          }`}
        >
          <svg
            className="h-5 w-5"
            fill={profileActive ? "currentColor" : "none"}
            stroke="currentColor"
            strokeWidth={2}
            viewBox="0 0 24 24"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              d="M20 21a8 8 0 10-16 0m12-11a4 4 0 11-8 0 4 4 0 018 0z"
            />
          </svg>
          <span className="text-[10px] font-medium">Profile</span>
        </Link>

        <button
          type="button"
          onClick={onOpenSearch}
          className={`flex h-full w-full flex-col items-center justify-center gap-1 pb-2 ${
            isActive("/search") ? "text-emerald-brand" : "text-gray-500"
          }`}
        >
          <svg
            className="h-5 w-5"
            fill="none"
            stroke="currentColor"
            strokeWidth={2}
            viewBox="0 0 24 24"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"
            />
          </svg>
          <span className="text-[10px] font-medium">Search</span>
        </button>
      </div>
    </nav>
  );
}
