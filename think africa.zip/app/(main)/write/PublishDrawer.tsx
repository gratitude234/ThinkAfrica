"use client";

import { useEffect, useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import slugify from "slugify";
import { createClient } from "@/lib/supabase/client";
import Button from "@/components/ui/Button";
import Badge from "@/components/ui/Badge";
import TagInput from "@/components/ui/TagInput";
import CoverImageUploader from "@/components/ui/CoverImageUploader";
import {
  generateExcerpt,
  MIN_WORD_COUNTS,
  POST_TYPE_INTENTS,
  POST_TYPE_LABELS,
  type PostType,
} from "@/lib/utils";
import {
  CANONICAL_TAGS,
  getSuggestedTags,
  normalizeTagValue,
} from "@/lib/tags";
import { composeContentWithSubtitle, inferTypeFromContent } from "./writeUtils";

interface PublishDrawerProps {
  open: boolean;
  onClose: () => void;
  draftId: string | null;
  title: string;
  subtitle: string;
  content: string;
  wordCount: number;
  userId: string;
  initialTags?: string[];
  initialCoverImageUrl?: string;
  initialExcerpt?: string;
  initialPostType?: PostType;
  onMetadataChange?: (changes: {
    postType?: PostType;
    tags?: string[];
    coverImageUrl?: string;
    excerpt?: string;
  }) => void;
}

const POST_TYPES: PostType[] = ["blog", "essay", "policy_brief", "research"];

interface ProfileRow {
  full_name: string | null;
  university: string | null;
  field_of_study: string | null;
}

interface TagRow {
  tags: string[] | null;
}

function formatTypeSuggestionLabel(
  type: PostType,
  inferredType: PostType,
  wordCount: number,
  content: string
) {
  if (type !== inferredType) return null;

  const h2Count = (content.match(/<h2/gi) ?? []).length;
  return `Suggested based on your ${wordCount.toLocaleString()} words and ${h2Count} sections.`;
}

export default function PublishDrawer({
  open,
  onClose,
  draftId,
  title,
  subtitle,
  content,
  wordCount,
  userId,
  initialTags = [],
  initialCoverImageUrl = "",
  initialExcerpt = "",
  initialPostType,
  onMetadataChange,
}: PublishDrawerProps) {
  const router = useRouter();
  const [postType, setPostType] = useState<PostType>(
    initialPostType ?? inferTypeFromContent(content, wordCount)
  );
  const [tags, setTags] = useState<string[]>(initialTags);
  const [coverImageUrl, setCoverImageUrl] = useState(initialCoverImageUrl);
  const [excerpt, setExcerpt] = useState(
    initialExcerpt || generateExcerpt(content, 220)
  );
  const [publishing, setPublishing] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [profile, setProfile] = useState<ProfileRow | null>(null);
  const [platformTags, setPlatformTags] = useState<string[]>([]);

  const inferredType = useMemo(
    () => inferTypeFromContent(content, wordCount),
    [content, wordCount]
  );

  useEffect(() => {
    if (!open) return;

    setPostType(initialPostType ?? inferTypeFromContent(content, wordCount));
    setTags(initialTags);
    setCoverImageUrl(initialCoverImageUrl);
    setExcerpt(initialExcerpt || generateExcerpt(content, 220));
    setError(null);
  }, [
    open,
    initialPostType,
    content,
    wordCount,
    initialTags,
    initialCoverImageUrl,
    initialExcerpt,
  ]);

  useEffect(() => {
    if (!open || !userId) return;

    const supabase = createClient();

    Promise.all([
      supabase
        .from("profiles")
        .select("full_name, university, field_of_study")
        .eq("id", userId)
        .single(),
      supabase
        .from("posts")
        .select("tags")
        .eq("status", "published")
        .limit(500),
    ]).then(([profileResult, tagsResult]) => {
      setProfile((profileResult.data as ProfileRow | null) ?? null);

      const counts = new Map<string, number>();
      ((tagsResult.data ?? []) as TagRow[]).forEach((row) => {
        (row.tags ?? []).forEach((tag) => {
          const normalized = normalizeTagValue(tag);
          counts.set(normalized, (counts.get(normalized) ?? 0) + 1);
        });
      });

      const ranked = Array.from(counts.entries())
        .sort((left, right) => right[1] - left[1])
        .map(([tag]) => tag)
        .slice(0, 10);

      setPlatformTags(ranked);
    });
  }, [open, userId]);

  const suggestedTags = useMemo(
    () =>
      getSuggestedTags({
        content,
        fieldOfStudy: profile?.field_of_study,
        platformTags,
      }),
    [content, platformTags, profile?.field_of_study]
  );

  if (!open) return null;

  const minWords = MIN_WORD_COUNTS[postType];
  const isInstantPublish = postType === "blog" || postType === "essay";
  const authorName = profile?.full_name ?? "You";
  const authorUniversity = profile?.university ?? "ThinkAfrika";

  const handleTagChange = (nextTags: string[]) => {
    setTags(nextTags);
    onMetadataChange?.({ tags: nextTags });
  };

  const addSuggestedTag = (tag: string) => {
    const normalized = normalizeTagValue(tag);
    if (tags.includes(normalized) || tags.length >= 5) return;
    handleTagChange([...tags, normalized]);
  };

  const handlePublish = async () => {
    if (!title.trim()) {
      setError("Please enter a title.");
      return;
    }

    if (wordCount < minWords) {
      const confirmed = window.confirm(
        `${POST_TYPE_LABELS[postType]} posts usually run at least ${minWords.toLocaleString()} words. You have ${wordCount.toLocaleString()}. Publish anyway?`
      );
      if (!confirmed) return;
    }

    setPublishing(true);
    setError(null);

    const supabase = createClient();
    const {
      data: { user },
    } = await supabase.auth.getUser();

    if (!user) {
      setPublishing(false);
      router.push("/login");
      return;
    }

    const finalExcerpt = excerpt.trim() || generateExcerpt(content, 220);
    const normalizedTags = tags.map((tag) => normalizeTagValue(tag)).filter(Boolean);
    const contentWithSubtitle = composeContentWithSubtitle(content, subtitle);
    const now = new Date().toISOString();
    const submitStatus = isInstantPublish ? "published" : "pending";
    const submitPublishedAt = isInstantPublish ? now : null;
    let publishedPostSlug = "";

    if (draftId) {
      const { data: updated, error: updateError } = await supabase
        .from("posts")
        .update({
          title: title.trim(),
          excerpt: finalExcerpt,
          content: contentWithSubtitle,
          tags: normalizedTags,
          type: postType,
          cover_image_url: coverImageUrl || null,
          status: submitStatus,
          published_at: submitPublishedAt,
        })
        .eq("id", draftId)
        .eq("author_id", user.id)
        .select("slug")
        .single();

      if (updateError || !updated) {
        setError(updateError?.message ?? "Failed to publish.");
        setPublishing(false);
        return;
      }

      publishedPostSlug = updated.slug;
    } else {
      const baseSlug = slugify(title, { lower: true, strict: true });
      const uniqueSlug = `${baseSlug}-${Date.now().toString(36)}`;

      const { data: inserted, error: insertError } = await supabase
        .from("posts")
        .insert({
          author_id: user.id,
          title: title.trim(),
          slug: uniqueSlug,
          content: contentWithSubtitle,
          excerpt: finalExcerpt,
          type: postType,
          tags: normalizedTags,
          status: submitStatus,
          published_at: submitPublishedAt,
          cover_image_url: coverImageUrl || null,
        })
        .select("slug")
        .single();

      if (insertError || !inserted) {
        setError(insertError?.message ?? "Failed to publish.");
        setPublishing(false);
        return;
      }

      publishedPostSlug = inserted.slug;
    }

    router.push(
      `/post/${publishedPostSlug}?justPublished=1&live=${
        isInstantPublish ? "1" : "0"
      }`
    );
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/40">
      <button
        type="button"
        onClick={onClose}
        className="absolute inset-0 cursor-default"
        aria-label="Close publish drawer backdrop"
      />

      <div className="absolute right-0 top-0 h-full w-full overflow-y-auto bg-white shadow-2xl sm:w-[440px]">
        <div className="sticky top-0 z-10 flex items-center justify-between border-b border-gray-100 bg-white px-5 py-4">
          <div>
            <h2 className="text-lg font-semibold text-gray-900">
              Ready to publish?
            </h2>
            <p className="text-xs text-gray-400">
              Finalize the details before your post goes live.
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="text-2xl leading-none text-gray-400 transition-colors hover:text-gray-600"
            aria-label="Close publish drawer"
          >
            ×
          </button>
        </div>

        <div className="space-y-6 px-5 py-5">
          <section className="space-y-3">
            <div>
              <p className="text-sm font-medium text-gray-900">
                What kind of post is this?
              </p>
              <p className="mt-1 text-xs text-gray-500">
                We suggested a format based on your draft. You can override it.
              </p>
            </div>

            <div className="space-y-2">
              {POST_TYPES.map((type) => {
                const suggestionLabel = formatTypeSuggestionLabel(
                  type,
                  inferredType,
                  wordCount,
                  content
                );

                return (
                  <button
                    key={type}
                    type="button"
                    onClick={() => {
                      setPostType(type);
                      onMetadataChange?.({ postType: type });
                    }}
                    className={`w-full rounded-xl border px-4 py-3 text-left transition-colors ${
                      postType === type
                        ? "border-emerald-brand bg-emerald-50"
                        : "border-gray-200 hover:border-emerald-300"
                    }`}
                  >
                    <div className="flex items-center justify-between gap-3">
                      <div>
                        <p className="text-sm font-medium text-gray-900">
                          {POST_TYPE_LABELS[type]}
                        </p>
                        <p className="mt-1 text-xs text-gray-500">
                          {POST_TYPE_INTENTS[type]}
                        </p>
                      </div>
                      {suggestionLabel ? (
                        <span className="rounded-full bg-gray-100 px-2 py-0.5 text-[11px] font-medium text-gray-600">
                          Suggested
                        </span>
                      ) : null}
                    </div>
                    {suggestionLabel ? (
                      <p className="mt-2 text-[11px] text-gray-400">
                        {suggestionLabel}
                      </p>
                    ) : null}
                  </button>
                );
              })}
            </div>
          </section>

          <section className="space-y-3">
            <div>
              <p className="text-sm font-medium text-gray-900">Tags</p>
              <p className="mt-1 text-xs text-gray-500">
                Suggested from your content, profile, and popular topics.
              </p>
            </div>

            {suggestedTags.length > 0 ? (
              <div>
                <p className="mb-2 text-xs font-medium uppercase tracking-wide text-gray-400">
                  Suggested tags
                </p>
                <div className="flex flex-wrap gap-2">
                  {suggestedTags.map((tag) => (
                    <button
                      key={tag}
                      type="button"
                      onClick={() => addSuggestedTag(tag)}
                      disabled={tags.includes(normalizeTagValue(tag))}
                      className="rounded-full border border-gray-200 px-3 py-1 text-xs font-medium text-gray-700 transition-colors hover:border-emerald-brand hover:text-emerald-brand disabled:cursor-not-allowed disabled:bg-gray-50 disabled:text-gray-400"
                    >
                      + {tag}
                    </button>
                  ))}
                </div>
              </div>
            ) : null}

            <TagInput
              label="Topics"
              value={tags}
              maxTags={5}
              helperText={`Suggested from ${CANONICAL_TAGS.length} canonical tags. Freeform tags still work for now.`}
              placeholder="Add a topic"
              onChange={handleTagChange}
            />
          </section>

          <section className="space-y-3">
            <div>
              <p className="text-sm font-medium text-gray-900">
                Cover image (optional)
              </p>
              <p className="mt-1 text-xs text-gray-500">
                If not provided, we&apos;ll show a branded card with your title.
              </p>
            </div>

            <CoverImageUploader
              initialUrl={coverImageUrl}
              onUpload={(url) => {
                setCoverImageUrl(url);
                onMetadataChange?.({ coverImageUrl: url });
              }}
              onRemove={() => {
                setCoverImageUrl("");
                onMetadataChange?.({ coverImageUrl: "" });
              }}
            />
          </section>

          <section className="space-y-3">
            <div>
              <p className="text-sm font-medium text-gray-900">Feed summary</p>
              <p className="mt-1 text-xs text-gray-500">
                Auto-generated — edit if you want.
              </p>
            </div>
            <textarea
              value={excerpt}
              onChange={(event) => {
                setExcerpt(event.target.value);
                onMetadataChange?.({ excerpt: event.target.value });
              }}
              rows={4}
              maxLength={220}
              className="w-full resize-none rounded-xl border border-gray-200 px-3 py-2 text-sm focus:border-transparent focus:outline-none focus:ring-2 focus:ring-emerald-brand"
            />
          </section>

          <section className="space-y-3">
            <div>
              <p className="text-sm font-medium text-gray-900">Preview</p>
              <p className="mt-1 text-xs text-gray-500">
                This matches how the card will appear in the feed.
              </p>
            </div>

            <article className="overflow-hidden rounded-2xl border border-gray-100 bg-white shadow-sm">
              <div className="relative aspect-[16/9] w-full overflow-hidden">
                {coverImageUrl ? (
                  // eslint-disable-next-line @next/next/no-img-element
                  <img
                    src={coverImageUrl}
                    alt={title}
                    className="h-full w-full object-cover"
                  />
                ) : (
                  <div className="flex h-full w-full items-center justify-center bg-gradient-to-br from-emerald-50 to-emerald-100">
                    <span className="text-sm font-semibold uppercase tracking-widest text-emerald-600/80">
                      {POST_TYPE_LABELS[postType]}
                    </span>
                  </div>
                )}
              </div>

              <div className="p-5">
                <div className="flex items-center justify-between gap-3">
                  <Badge type={postType} />
                  <span className="text-xs text-gray-400">
                    {Math.max(
                      1,
                      Math.ceil(
                        (excerpt.trim().split(/\s+/).filter(Boolean).length || 0) /
                          200
                      )
                    )}{" "}
                    min read
                  </span>
                </div>

                <h3 className="mt-3 line-clamp-2 text-lg font-semibold text-gray-900">
                  {title || "Untitled draft"}
                </h3>
                {excerpt.trim() ? (
                  <p className="mt-2 line-clamp-2 text-sm leading-relaxed text-gray-500">
                    {excerpt}
                  </p>
                ) : null}

                <div className="mt-4 border-t border-gray-100 pt-4">
                  <p className="text-sm font-medium text-gray-900">{authorName}</p>
                  <p className="text-xs text-gray-400">{authorUniversity}</p>
                </div>
              </div>
            </article>
          </section>

          <p className="text-sm text-gray-500">
            {isInstantPublish
              ? "Publishes instantly."
              : "Enters editorial review. Usually live within 48 hours."}
          </p>

          {error ? (
            <div className="rounded-lg border border-red-200 bg-red-50 px-3 py-2 text-sm text-red-600">
              {error}
            </div>
          ) : null}

          <Button
            type="button"
            size="lg"
            className="w-full"
            loading={publishing}
            onClick={handlePublish}
          >
            Publish
          </Button>
        </div>
      </div>
    </div>
  );
}
