"use server";

import { revalidatePath } from "next/cache";
import slugify from "slugify";
import { createClient } from "@/lib/supabase/server";
import { createAdminClient } from "@/lib/supabase/admin";
import { generateCitationId } from "@/lib/citationId";
import type { PostReferenceRecord } from "@/lib/types";
import type { PostType } from "@/lib/utils";

type ReferenceInput = Omit<PostReferenceRecord, "post_id"> & {
  id?: string;
};

type CoAuthorInput = {
  user_id: string;
  display_order: number;
  corresponding_author?: boolean;
};

async function getCurrentUser() {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) {
    return { supabase, user: null };
  }

  return { supabase, user };
}

async function syncReferences(
  supabase: Awaited<ReturnType<typeof createClient>>,
  postId: string,
  references: ReferenceInput[]
) {
  const { data: existingRows, error: existingError } = await supabase
    .from("post_references")
    .select("id")
    .eq("post_id", postId);

  if (existingError) {
    throw new Error(existingError.message);
  }

  const existingIds = new Set((existingRows ?? []).map((row) => row.id));
  const incomingIds = new Set(
    references.map((reference) => reference.id).filter(Boolean) as string[]
  );

  const idsToDelete = Array.from(existingIds).filter((id) => !incomingIds.has(id));

  if (idsToDelete.length > 0) {
    const { error } = await supabase
      .from("post_references")
      .delete()
      .eq("post_id", postId)
      .in("id", idsToDelete);

    if (error) {
      throw new Error(error.message);
    }
  }

  for (let index = 0; index < references.length; index += 1) {
    const reference = references[index];
    const payload = {
      post_id: postId,
      display_order: index,
      ref_type: reference.ref_type ?? "other",
      authors: reference.authors?.trim() || null,
      title: reference.title.trim(),
      year: reference.year ?? null,
      source: reference.source?.trim() || null,
      url: reference.url?.trim() || null,
      doi: reference.doi?.trim() || null,
      raw: reference.raw?.trim() || null,
    };

    if (reference.id) {
      const { error } = await supabase
        .from("post_references")
        .update(payload)
        .eq("id", reference.id)
        .eq("post_id", postId);

      if (error) {
        throw new Error(error.message);
      }
    } else {
      const { error } = await supabase.from("post_references").insert(payload);

      if (error) {
        throw new Error(error.message);
      }
    }
  }
}

async function syncCoAuthors(
  supabase: Awaited<ReturnType<typeof createClient>>,
  postId: string,
  slug: string,
  ownerId: string,
  coAuthors: CoAuthorInput[],
  ownerName: string
) {
  const sanitized = coAuthors
    .filter((coAuthor) => coAuthor.user_id && coAuthor.user_id !== ownerId)
    .slice(0, 5)
    .map((coAuthor, index) => ({
      post_id: postId,
      user_id: coAuthor.user_id,
      display_order: index + 1,
      corresponding_author: false,
    }));

  const { data: existing } = await supabase
    .from("post_authors")
    .select("user_id, accepted_at")
    .eq("post_id", postId);

  const existingIds = new Set((existing ?? []).map((row) => row.user_id));
  const nextIds = new Set(sanitized.map((coAuthor) => coAuthor.user_id));
  const removedIds = Array.from(existingIds).filter((id) => !nextIds.has(id));

  if (removedIds.length > 0) {
    await supabase
      .from("post_authors")
      .delete()
      .eq("post_id", postId)
      .in("user_id", removedIds);
  }

  for (const coAuthor of sanitized) {
    if (existingIds.has(coAuthor.user_id)) {
      await supabase
        .from("post_authors")
        .update({
          display_order: coAuthor.display_order,
          corresponding_author: false,
        })
        .eq("post_id", postId)
        .eq("user_id", coAuthor.user_id);
      continue;
    }

    await supabase.from("post_authors").insert({
      ...coAuthor,
      accepted_at: null,
    });

    await supabase.from("notifications").insert({
      user_id: coAuthor.user_id,
      type: "co_author_invite",
      message: `${ownerName} has invited you to co-author this post.`,
      link: `/post/${slug}`,
      actor_id: ownerId,
      post_id: postId,
      read: false,
    });
  }
}

export async function ensureDraft(input: {
  draftId: string | null;
  title: string;
  subtitle: string;
  excerpt: string;
  content: string;
  tags: string[];
  postType: PostType;
  coverImageUrl: string;
}) {
  const { supabase, user } = await getCurrentUser();

  if (!user) {
    return { error: "You must be signed in.", draftId: null as string | null };
  }

  const slugBase = slugify(input.title || "untitled", {
    lower: true,
    strict: true,
  });
  const slug = `${slugBase || "untitled"}-${Date.now().toString(36)}`;
  const normalizedTags = input.tags.map((tag) => tag.trim().toLowerCase()).filter(Boolean);

  if (input.draftId) {
    const { error } = await supabase
      .from("posts")
      .update({
        title: input.title || "Untitled draft",
        excerpt: input.excerpt,
        content: input.content,
        tags: normalizedTags,
        type: input.postType,
        cover_image_url: input.coverImageUrl || null,
      })
      .eq("id", input.draftId)
      .eq("author_id", user.id);

    return { error: error?.message ?? null, draftId: input.draftId };
  }

  const { data, error } = await supabase
    .from("posts")
    .insert({
      author_id: user.id,
      title: input.title || "Untitled draft",
      slug,
      excerpt: input.excerpt,
      content: input.content,
      tags: normalizedTags,
      type: input.postType,
      status: "draft",
      cover_image_url: input.coverImageUrl || null,
    })
    .select("id")
    .single();

  return { error: error?.message ?? null, draftId: data?.id ?? null };
}

export async function savePostReferences(input: {
  postId: string;
  references: ReferenceInput[];
}) {
  const { supabase, user } = await getCurrentUser();

  if (!user) {
    return { error: "You must be signed in." };
  }

  const { data: post } = await supabase
    .from("posts")
    .select("author_id")
    .eq("id", input.postId)
    .single();

  if (!post || post.author_id !== user.id) {
    return { error: "You do not have permission to edit these references." };
  }

  try {
    await syncReferences(supabase, input.postId, input.references);
    return { error: null };
  } catch (error) {
    return {
      error: error instanceof Error ? error.message : "Failed to save references.",
    };
  }
}

export async function publishPost(input: {
  draftId: string | null;
  title: string;
  subtitle: string;
  excerpt: string;
  content: string;
  tags: string[];
  postType: PostType;
  coverImageUrl: string;
  customSlug?: string;
  coAuthors?: CoAuthorInput[];
  references?: ReferenceInput[];
}) {
  const { supabase, user } = await getCurrentUser();

  if (!user) {
    return { error: "You must be signed in.", slug: null as string | null };
  }

  const { data: ownerProfile } = await supabase
    .from("profiles")
    .select("full_name")
    .eq("id", user.id)
    .single();

  const now = new Date().toISOString();
  const slug =
    input.customSlug?.trim() ||
    `${slugify(input.title, { lower: true, strict: true })}-${Date.now().toString(36)}`;
  const submitStatus =
    input.postType === "blog" || input.postType === "essay"
      ? "published"
      : "pending";
  const publishedAt = submitStatus === "published" ? now : null;
  const normalizedTags = input.tags.map((tag) => tag.trim().toLowerCase()).filter(Boolean);

  let postId = input.draftId;

  if (postId) {
    const { error } = await supabase
      .from("posts")
      .update({
        title: input.title.trim(),
        excerpt: input.excerpt,
        content: input.content,
        tags: normalizedTags,
        type: input.postType,
        cover_image_url: input.coverImageUrl || null,
        status: submitStatus,
        published_at: publishedAt,
        slug,
      })
      .eq("id", postId)
      .eq("author_id", user.id);

    if (error) {
      return { error: error.message, slug: null as string | null };
    }
  } else {
    const { data, error } = await supabase
      .from("posts")
      .insert({
        author_id: user.id,
        title: input.title.trim(),
        slug,
        content: input.content,
        excerpt: input.excerpt,
        type: input.postType,
        tags: normalizedTags,
        status: submitStatus,
        published_at: publishedAt,
        cover_image_url: input.coverImageUrl || null,
      })
      .select("id")
      .single();

    if (error || !data) {
      return { error: error?.message ?? "Failed to publish.", slug: null as string | null };
    }

    postId = data.id;
  }

  if (!postId) {
    return { error: "Unable to resolve the draft.", slug: null as string | null };
  }

  if (input.references) {
    try {
      await syncReferences(supabase, postId, input.references);
    } catch (error) {
      return {
        error:
          error instanceof Error ? error.message : "Failed to save references.",
        slug: null as string | null,
      };
    }
  }

  if (input.coAuthors) {
    await syncCoAuthors(
      supabase,
      postId,
      slug,
      user.id,
      input.coAuthors,
      ownerProfile?.full_name ?? "A ThinkAfrika author"
    );
  }

  if (submitStatus === "published" &&
      (input.postType === "research" || input.postType === "policy_brief")) {
    const admin = createAdminClient();
    const citationId = await generateCitationId(admin, new Date().getFullYear());
    await admin
      .from("posts")
      .update({ citation_id: citationId })
      .eq("id", postId)
      .is("citation_id", null);
  }

  revalidatePath("/dashboard");
  revalidatePath(`/post/${slug}`);
  revalidatePath("/");

  return { error: null, slug };
}
