"use server";

import { revalidatePath } from "next/cache";
import { createClient } from "@/lib/supabase/server";
import { createAdminClient } from "@/lib/supabase/admin";
import type { PostReferenceRecord, PostStatus } from "@/lib/types";
import type { PostType } from "@/lib/utils";

type ReferenceInput = Omit<PostReferenceRecord, "post_id"> & {
  id?: string;
};

async function syncReferences(
  supabase: Awaited<ReturnType<typeof createClient>>,
  postId: string,
  references: ReferenceInput[]
) {
  const { data: existingRows } = await supabase
    .from("post_references")
    .select("id")
    .eq("post_id", postId);

  const existingIds = new Set((existingRows ?? []).map((row) => row.id));
  const incomingIds = new Set(
    references.map((reference) => reference.id).filter(Boolean) as string[]
  );

  const idsToDelete = Array.from(existingIds).filter((id) => !incomingIds.has(id));

  if (idsToDelete.length > 0) {
    await supabase
      .from("post_references")
      .delete()
      .eq("post_id", postId)
      .in("id", idsToDelete);
  }

  for (let index = 0; index < references.length; index += 1) {
    const reference = references[index];
    const payload = {
      post_id: postId,
      display_order: index,
      ref_type: reference.ref_type ?? "other",
      authors: reference.authors?.trim() || null,
      title: reference.title.trim(),
      year: reference.year ?? null,
      source: reference.source?.trim() || null,
      url: reference.url?.trim() || null,
      doi: reference.doi?.trim() || null,
      raw: reference.raw?.trim() || null,
    };

    if (reference.id && !reference.id.startsWith("temp-")) {
      await supabase
        .from("post_references")
        .update(payload)
        .eq("id", reference.id)
        .eq("post_id", postId);
    } else {
      await supabase.from("post_references").insert(payload);
    }
  }
}

export async function saveEditedPost(input: {
  postId: string;
  title: string;
  excerpt: string;
  content: string;
  tags: string[];
  postType: PostType;
  coverImageUrl: string;
  currentStatus: PostStatus;
  currentRound: number;
  authorNote: string;
  references: ReferenceInput[];
}) {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) {
    return { error: "You must be signed in." };
  }

  const { data: post } = await supabase
    .from("posts")
    .select("author_id, title, excerpt, content, current_round, slug")
    .eq("id", input.postId)
    .single();

  if (!post || post.author_id !== user.id) {
    return { error: "You do not have permission to edit this post." };
  }

  if (input.currentStatus === "pending_revision") {
    const admin = createAdminClient();
    const { error: versionError } = await admin.from("post_versions").insert({
      post_id: input.postId,
      version_number: input.currentRound,
      title: post.title,
      excerpt: post.excerpt,
      content: post.content ?? "",
      author_note: input.authorNote.trim() || null,
    });

    if (versionError) {
      return { error: versionError.message };
    }
  }

  const nextStatus =
    input.currentStatus === "pending_revision" ? "pending" : input.currentStatus;

  const { error } = await supabase
    .from("posts")
    .update({
      title: input.title.trim(),
      excerpt: input.excerpt,
      content: input.content,
      tags: input.tags.map((tag) => tag.trim().toLowerCase()).filter(Boolean),
      type: input.postType,
      cover_image_url: input.coverImageUrl || null,
      status: nextStatus,
      current_round:
        input.currentStatus === "pending_revision"
          ? input.currentRound + 1
          : input.currentRound,
      revision_due_at: input.currentStatus === "pending_revision" ? null : undefined,
    })
    .eq("id", input.postId)
    .eq("author_id", user.id);

  if (error) {
    return { error: error.message };
  }

  await syncReferences(supabase, input.postId, input.references);

  revalidatePath("/dashboard");
  revalidatePath(`/edit/${post.slug}`);
  revalidatePath(`/post/${post.slug}`);

  return { error: null };
}
