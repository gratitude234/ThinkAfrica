"use client";

import { useState, useCallback, useEffect, useRef } from "react";
import { useRouter } from "next/navigation";
import dynamic from "next/dynamic";
import Button from "@/components/ui/Button";
import TagInput from "@/components/ui/TagInput";
import { MIN_WORD_COUNTS, POST_TYPE_LABELS, type PostType } from "@/lib/utils";
import CoverImageUploader from "@/components/ui/CoverImageUploader";
import type { PostReferenceRecord, PostStatus } from "@/lib/types";
import { saveEditedPost } from "./actions";

const Editor = dynamic(() => import("@/components/editor/Editor"), {
  ssr: false,
  loading: () => (
    <div className="min-h-[400px] rounded-lg border border-gray-200 bg-canvas animate-pulse" />
  ),
});

const POST_TYPES: PostType[] = ["blog", "essay", "research", "policy_brief"];

interface Post {
  id: string;
  title: string;
  excerpt: string | null;
  content: string | null;
  type: string;
  status: PostStatus;
  tags: string[] | null;
  cover_image_url: string | null;
  current_round: number;
  revision_due_at: string | null;
}

interface EditFormProps {
  post: Post;
  userId: string;
  initialReferences: PostReferenceRecord[];
  reviewNotes: Array<{
    id: string;
    recommendation: string | null;
    notes: string | null;
    submitted_at: string | null;
    reviewer: { full_name: string | null; username: string } | null;
  }>;
}

export default function EditForm({
  post,
  initialReferences,
  reviewNotes,
}: EditFormProps) {
  const router = useRouter();
  const [postType, setPostType] = useState<PostType>((post.type as PostType) ?? "blog");
  const [title, setTitle] = useState(post.title);
  const [excerpt, setExcerpt] = useState(post.excerpt ?? "");
  const [tags, setTags] = useState<string[]>(post.tags ?? []);
  const [content, setContent] = useState(post.content ?? "");
  const [coverImageUrl, setCoverImageUrl] = useState(post.cover_image_url ?? "");
  const [references, setReferences] = useState<PostReferenceRecord[]>(initialReferences);
  const [authorNote, setAuthorNote] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const autosaveTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  const doSave = useCallback(
    async (silent = false) => {
      if (!silent) {
        setLoading(true);
      }

      setError(null);
      const { error: updateError } = await saveEditedPost({
        postId: post.id,
        title,
        excerpt,
        content,
        tags,
        postType,
        coverImageUrl,
        currentStatus: post.status,
        currentRound: post.current_round,
        authorNote,
        references,
      });

      if (updateError) {
        if (!silent) {
          setError(updateError);
        }
      } else if (!silent) {
        router.push("/dashboard");
      }

      if (!silent) {
        setLoading(false);
      }
    },
    [
      title,
      excerpt,
      content,
      tags,
      postType,
      coverImageUrl,
      post.id,
      post.status,
      post.current_round,
      authorNote,
      references,
      router,
    ]
  );

  useEffect(() => {
    if (autosaveTimer.current) {
      clearTimeout(autosaveTimer.current);
    }

    autosaveTimer.current = setTimeout(() => {
      void doSave(true);
    }, 5000);

    return () => {
      if (autosaveTimer.current) {
        clearTimeout(autosaveTimer.current);
      }
    };
  }, [title, excerpt, tags, postType, coverImageUrl, references, authorNote, doSave]);

  const handleEditorUpdate = useCallback((html: string) => {
    setContent(html);
  }, []);

  return (
    <div className="mx-auto max-w-3xl">
      <div className="mb-8 flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Edit post</h1>
          <p className="mt-1 text-sm capitalize text-gray-500">
            Status: <span className="font-medium">{post.status}</span>
          </p>
        </div>
      </div>

      <form
        onSubmit={(e) => {
          e.preventDefault();
          void doSave(false);
        }}
        className="space-y-6"
      >
        {post.status === "pending_revision" ? (
          <div className="rounded-xl border border-amber-200 bg-amber-50 p-4">
            <p className="text-sm font-medium text-amber-900">
              Reviewer feedback received — revise by{" "}
              {post.revision_due_at
                ? new Date(post.revision_due_at).toLocaleDateString("en-US", {
                    year: "numeric",
                    month: "long",
                    day: "numeric",
                  })
                : "the requested deadline"}
              .
            </p>
            {reviewNotes.length > 0 ? (
              <div className="mt-3 space-y-3">
                {reviewNotes.map((note) => (
                  <div
                    key={note.id}
                    className="rounded-lg border border-amber-100 bg-white px-3 py-3"
                  >
                    <p className="text-xs font-semibold uppercase tracking-wide text-amber-700">
                      {note.recommendation}
                    </p>
                    <p className="mt-1 text-sm text-gray-700">
                      {note.notes || "No written note provided."}
                    </p>
                    <p className="mt-1 text-xs text-gray-400">
                      {note.reviewer?.full_name ?? note.reviewer?.username ?? "Reviewer"}
                    </p>
                  </div>
                ))}
              </div>
            ) : null}
          </div>
        ) : null}

        <CoverImageUploader
          initialUrl={coverImageUrl}
          onUpload={setCoverImageUrl}
          onRemove={() => setCoverImageUrl("")}
        />

        <div>
          <label className="mb-2 block text-sm font-medium text-gray-700">
            Post type
          </label>
          <div className="flex flex-wrap gap-2">
            {POST_TYPES.map((type) => (
              <button
                key={type}
                type="button"
                onClick={() => setPostType(type)}
                className={`rounded-lg border px-4 py-2 text-sm font-medium transition-colors ${
                  postType === type
                    ? "border-emerald-brand bg-emerald-brand text-white"
                    : "border-gray-200 bg-white text-gray-600 hover:border-emerald-brand hover:text-emerald-brand"
                }`}
              >
                {POST_TYPE_LABELS[type]}
              </button>
            ))}
          </div>
        </div>

        <div>
          <label className="mb-1 block text-sm font-medium text-gray-700">
            Title
          </label>
          <input
            type="text"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            required
            className="w-full rounded-lg border border-gray-200 px-3 py-2 text-base font-medium focus:border-transparent focus:outline-none focus:ring-2 focus:ring-emerald-brand"
          />
        </div>

        <div>
          <label className="mb-1 block text-sm font-medium text-gray-700">
            Summary
          </label>
          <div className="relative">
            <textarea
              value={excerpt}
              onChange={(e) => setExcerpt(e.target.value)}
              maxLength={200}
              rows={2}
              className="w-full resize-none rounded-lg border border-gray-200 px-3 py-2 text-sm focus:border-transparent focus:outline-none focus:ring-2 focus:ring-emerald-brand"
            />
            <span className="absolute bottom-2 right-2 text-xs text-gray-400">
              {excerpt.length}/200
            </span>
          </div>
        </div>

        <TagInput
          label="Tags"
          value={tags}
          helperText="Add up to five tags to keep this post discoverable."
          onChange={setTags}
        />

        <div>
          <label className="mb-1 block text-sm font-medium text-gray-700">
            Content
          </label>
          <Editor
            content={content}
            minWords={MIN_WORD_COUNTS[postType]}
            postType={postType}
            references={references}
            onReferencesChange={setReferences}
            onUpdate={handleEditorUpdate}
            onAutoSave={() => doSave(true)}
          />
        </div>

        {post.status === "pending_revision" ? (
          <div>
            <label className="mb-1 block text-sm font-medium text-gray-700">
              Author&apos;s note for this revision
            </label>
            <textarea
              value={authorNote}
              onChange={(event) => setAuthorNote(event.target.value)}
              rows={3}
              className="w-full resize-none rounded-lg border border-gray-200 px-3 py-2 text-sm focus:border-transparent focus:outline-none focus:ring-2 focus:ring-emerald-brand"
              placeholder="Summarize what you changed in response to the reviewer feedback."
            />
          </div>
        ) : null}

        {error ? (
          <div className="rounded-lg border border-red-200 bg-red-50 px-3 py-2 text-sm text-red-600">
            {error}
          </div>
        ) : null}

        <div className="flex items-center justify-end gap-3 pt-2">
          <Button
            variant="secondary"
            type="button"
            onClick={() => router.push("/dashboard")}
          >
            Cancel
          </Button>
          <Button type="submit" loading={loading} size="lg">
            Save changes
          </Button>
        </div>
      </form>
    </div>
  );
}
