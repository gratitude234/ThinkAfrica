import { notFound, redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import { canReview } from "@/lib/roles";
import Badge from "@/components/ui/Badge";
import SubmitReviewForm from "../SubmitReviewForm";

interface PageProps {
  params: Promise<{ postId: string }>;
}

export default async function ReviewDetailPage({ params }: PageProps) {
  const { postId } = await params;
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) redirect("/login");

  const { data: profile } = await supabase
    .from("profiles")
    .select("role")
    .eq("id", user.id)
    .single();

  if (!profile?.role || !canReview(profile.role)) {
    redirect("/");
  }

  const { data: assignment } = await supabase
    .from("post_reviews")
    .select("id, recommendation")
    .eq("post_id", postId)
    .eq("reviewer_id", user.id)
    .single();

  if (!assignment || assignment.recommendation) notFound();

  const { data: post } = await supabase
    .from("posts")
    .select(
      "id, title, excerpt, content, type, tags, profiles!posts_author_id_fkey(full_name, username, university)"
    )
    .eq("id", postId)
    .single();

  if (!post) notFound();

  const author = Array.isArray(post.profiles) ? post.profiles[0] : post.profiles;

  return (
    <div className="mx-auto grid max-w-6xl gap-8 lg:grid-cols-[minmax(0,1fr)_340px]">
      <article className="rounded-2xl border border-gray-200 bg-white p-6">
        <div className="mb-4 flex items-center gap-2">
          <Badge type={post.type} />
          <span className="text-xs text-gray-400">
            {author?.full_name ?? author?.username} · {author?.university}
          </span>
        </div>
        <h1 className="font-display text-3xl font-bold text-gray-900">
          {post.title}
        </h1>
        {post.excerpt ? (
          <p className="mt-3 text-sm leading-relaxed text-gray-500">
            {post.excerpt}
          </p>
        ) : null}
        <div
          className="prose prose-gray mt-8 max-w-none prose-a:text-emerald-brand"
          dangerouslySetInnerHTML={{ __html: post.content ?? "" }}
        />
      </article>

      <aside>
        <SubmitReviewForm postId={postId} />
      </aside>
    </div>
  );
}
