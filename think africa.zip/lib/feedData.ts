import type { PostCardData } from "@/components/post/PostCard";
import { rankPosts, type RankingContext } from "@/lib/feedRanking";
import { createAdminClient } from "@/lib/supabase/admin";

export type FeedTabKey = "home" | "following" | "latest";
export type FeedTimeframe = "all" | "week" | "month";

export interface FeedPageResult {
  posts: PostCardData[];
  hasMore: boolean;
}

interface FeedOptions {
  supabase: {
    from: (table: string) => any;
  };
  tab: FeedTabKey;
  page: number;
  pageSize: number;
  type: string | null;
  timeframe: FeedTimeframe;
  userId: string | null;
  userInterests: string[];
  userUniversity: string | null;
  followedIds: string[];
}

const POST_SELECT =
  "id, title, slug, excerpt, type, tags, created_at, published_at, view_count, cover_image_url, author_id";

function getTimeframeCutoff(timeframe: FeedTimeframe): string | null {
  if (timeframe === "week") {
    return new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString();
  }
  if (timeframe === "month") {
    return new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString();
  }
  return null;
}

export async function getCountsByPostId(
  supabase: {
    from: (table: string) => any;
  },
  table: "likes" | "bookmarks" | "comments",
  postIds: string[]
): Promise<Record<string, number>> {
  if (postIds.length === 0) return {};

  const { data } = await supabase.from(table).select("post_id").in("post_id", postIds);

  return (data ?? []).reduce(
    (acc, row) => {
      const key = (row as { post_id?: string }).post_id;
      if (!key) return acc;
      acc[key] = (acc[key] ?? 0) + 1;
      return acc;
    },
    {} as Record<string, number>
  );
}

async function enrichPosts(
  supabase: {
    from: (table: string) => any;
  },
  raw: unknown[]
): Promise<PostCardData[]> {
  const ids = (raw as Array<{ id: string }>).map((post) => post.id);
  const authorIds = Array.from(
    new Set(
      (raw as Array<{ author_id?: string }>)
        .map((post) => post.author_id)
        .filter(Boolean) as string[]
    )
  );

  const [
    likeCounts,
    bookmarkCounts,
    commentCounts,
    profilesResult,
    postAuthorsResult,
  ] = await Promise.all([
    getCountsByPostId(supabase, "likes", ids),
    getCountsByPostId(supabase, "bookmarks", ids),
    getCountsByPostId(supabase, "comments", ids),
    authorIds.length > 0
      ? supabase
          .from("profiles")
          .select(
            "id, username, full_name, university, avatar_url, verified, verified_type"
          )
          .in("id", authorIds)
      : Promise.resolve({ data: [], error: null }),
    ids.length > 0
      ? supabase
          .from("post_authors")
          .select("post_id, user_id, display_order")
          .in("post_id", ids)
          .not("accepted_at", "is", null)
          .order("display_order", { ascending: true })
      : Promise.resolve({ data: [], error: null }),
  ]);

  const profiles = (profilesResult.data ?? []) as Array<{
    id: string;
    username: string;
    full_name: string | null;
    university: string | null;
    avatar_url: string | null;
    verified?: boolean;
    verified_type?: string | null;
  }>;

  const acceptedPostAuthors = (postAuthorsResult.data ?? []) as Array<{
    post_id: string;
    user_id: string;
    display_order: number;
  }>;

  const coAuthorIds = Array.from(
    new Set(acceptedPostAuthors.map((row) => row.user_id).filter(Boolean))
  );

  const coAuthorProfilesResult =
    coAuthorIds.length > 0
      ? await supabase
          .from("profiles")
          .select("id, username, full_name")
          .in("id", coAuthorIds)
      : { data: [], error: null };

  const profilesById = new Map(profiles.map((profile) => [profile.id, profile]));
  const coAuthorProfilesById = new Map(
    ((coAuthorProfilesResult.data ?? []) as Array<{
      id: string;
      username: string;
      full_name: string | null;
    }>).map((profile) => [profile.id, profile])
  );

  const coAuthorsByPostId = acceptedPostAuthors.reduce(
    (acc, row) => {
      const nextRow = {
        user_id: row.user_id,
        profile: coAuthorProfilesById.get(row.user_id)
          ? {
              username: coAuthorProfilesById.get(row.user_id)!.username,
              full_name: coAuthorProfilesById.get(row.user_id)!.full_name,
            }
          : null,
      };

      const current = acc[row.post_id] ?? [];
      current.push(nextRow);
      acc[row.post_id] = current;
      return acc;
    },
    {} as Record<
      string,
      Array<{
        user_id: string;
        profile: { username: string; full_name: string | null } | null;
      }>
    >
  );

  return (raw as Array<Record<string, unknown>>).map((post) => {
    const id = (post.id as string) ?? "";
    const authorId = (post.author_id as string) ?? "";

    return {
      ...(post as object),
      profiles: profilesById.get(authorId) ?? null,
      co_authors: coAuthorsByPostId[id] ?? [],
      like_count: likeCounts[id] ?? 0,
      bookmark_count: bookmarkCounts[id] ?? 0,
      comment_count: commentCounts[id] ?? 0,
    } as PostCardData;
  });
}

function applyPostFilters(
  query: any,
  {
    type,
    cutoff,
  }: {
    type: string | null;
    cutoff: string | null;
  }
) {
  let nextQuery = query.eq("status", "published");
  if (type && type !== "all") {
    nextQuery = nextQuery.eq("type", type);
  }
  if (cutoff) {
    nextQuery = nextQuery.gte("published_at", cutoff);
  }
  return nextQuery;
}

export async function fetchFeedPage({
  supabase,
  tab,
  page,
  pageSize,
  type,
  timeframe,
  userId,
  userInterests,
  userUniversity,
  followedIds,
}: FeedOptions): Promise<FeedPageResult> {
  const reader = process.env.SUPABASE_SERVICE_ROLE_KEY
    ? createAdminClient()
    : supabase;
  const safePage = Math.max(1, page);
  const safePageSize = Math.min(Math.max(pageSize, 1), 30);
  const cutoff = getTimeframeCutoff(timeframe);

  if (tab === "following") {
    if (followedIds.length === 0) {
      return { posts: [], hasMore: false };
    }

    const start = (safePage - 1) * safePageSize;
    const end = start + safePageSize;
    const query = applyPostFilters(
      reader.from("posts").select(POST_SELECT),
      { type, cutoff }
    );
    const { data } = await query
      .in("author_id", followedIds)
      .order("published_at", { ascending: false })
      .range(start, end);

    const raw = data ?? [];
    const posts = await enrichPosts(reader, raw.slice(0, safePageSize));
    return { posts, hasMore: raw.length > safePageSize };
  }

  if (tab === "latest") {
    const start = (safePage - 1) * safePageSize;
    const end = start + safePageSize;
    const query = applyPostFilters(
      reader.from("posts").select(POST_SELECT),
      { type, cutoff }
    );
    const { data } = await query
      .order("published_at", { ascending: false })
      .range(start, end);

    const raw = data ?? [];
    const posts = await enrichPosts(reader, raw.slice(0, safePageSize));
    return { posts, hasMore: raw.length > safePageSize };
  }

  const candidateLimit = Math.max(80, safePage * safePageSize + 20);
  const query = applyPostFilters(
    reader.from("posts").select(POST_SELECT),
    {
      type,
      cutoff,
    }
  );

  const { data } = await query
    .order("published_at", { ascending: false })
    .limit(candidateLimit);

  const enriched = await enrichPosts(reader, data ?? []);
  const rankingContext: RankingContext = {
    userId,
    followedIds: new Set(followedIds),
    userInterests,
    userUniversity,
    userCountry: null,
  };

  const ranked = rankPosts(enriched, rankingContext);
  const start = (safePage - 1) * safePageSize;
  const end = start + safePageSize;

  return {
    posts: ranked.slice(start, end),
    hasMore: ranked.length > end,
  };
}
