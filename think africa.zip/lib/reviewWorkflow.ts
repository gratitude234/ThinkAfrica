import "server-only";

import { addDays } from "@/lib/utils-date";
import { generateCitationId } from "@/lib/citationId";
import { createAdminClient } from "@/lib/supabase/admin";
import type { ReviewRecommendation } from "@/lib/types";

type ReviewRow = {
  id: string;
  reviewer_id: string;
  recommendation: ReviewRecommendation | null;
  submitted_at: string | null;
};

export async function resolveReviewCompletion(postId: string) {
  const admin = createAdminClient();

  const { data: post } = await admin
    .from("posts")
    .select("id, author_id, slug, title, type, status, current_round, citation_id")
    .eq("id", postId)
    .single();

  if (!post) {
    return { resolved: false, error: "Post not found." };
  }

  const { data: track } = await admin
    .from("submission_tracks")
    .select("requires_review, min_reviewers")
    .eq("post_type", post.type)
    .single();

  if (!track?.requires_review) {
    return { resolved: false, error: null };
  }

  const { data: reviews } = await admin
    .from("post_reviews")
    .select("id, reviewer_id, recommendation, submitted_at")
    .eq("post_id", postId)
    .eq("round", post.current_round);

  const currentRoundReviews = (reviews ?? []) as ReviewRow[];

  if (currentRoundReviews.length < track.min_reviewers) {
    return { resolved: false, error: null };
  }

  const allSubmitted = currentRoundReviews.every(
    (review) => review.recommendation && review.submitted_at
  );

  if (!allSubmitted) {
    return { resolved: false, error: null };
  }

  const counts = currentRoundReviews.reduce(
    (acc, review) => {
      if (review.recommendation) {
        acc[review.recommendation] += 1;
      }
      return acc;
    },
    { accept: 0, revise: 0, reject: 0 }
  );

  let nextStatus: "published" | "pending_revision" | "rejected" = "pending_revision";
  if (counts.accept > counts.revise && counts.accept > counts.reject) {
    nextStatus = "published";
  } else if (counts.reject > counts.accept && counts.reject > counts.revise) {
    nextStatus = "rejected";
  }

  if (nextStatus === "published") {
    const updatePayload: Record<string, unknown> = {
      status: "published",
      published_at: new Date().toISOString(),
    };

    if (
      !post.citation_id &&
      (post.type === "research" || post.type === "policy_brief")
    ) {
      updatePayload.citation_id = await generateCitationId(
        admin,
        new Date().getFullYear()
      );
    }

    await admin.from("posts").update(updatePayload).eq("id", postId);
    await admin.from("notifications").insert({
      user_id: post.author_id,
      type: "post_published",
      message: `Your post "${post.title}" has been published${
        updatePayload.citation_id
          ? `. Citation ID: ${updatePayload.citation_id}`
          : "."
      }`,
      link: `/post/${post.slug}`,
      post_id: post.id,
      read: false,
    });

    return { resolved: true, error: null, status: "published" as const };
  }

  if (nextStatus === "rejected") {
    await admin.from("posts").update({ status: "rejected" }).eq("id", postId);
    await admin.from("notifications").insert({
      user_id: post.author_id,
      type: "post_rejected",
      message: `Your post "${post.title}" was rejected after review.`,
      link: "/dashboard",
      post_id: post.id,
      read: false,
    });

    return { resolved: true, error: null, status: "rejected" as const };
  }

  const dueDate = addDays(new Date(), 14).toISOString();
  await admin
    .from("posts")
    .update({ status: "pending_revision", revision_due_at: dueDate })
    .eq("id", postId);
  await admin.from("notifications").insert({
    user_id: post.author_id,
    type: "revision_requested",
    message: `Reviewers have requested revisions on "${post.title}". Due by ${new Date(
      dueDate
    ).toLocaleDateString("en-US", {
      year: "numeric",
      month: "long",
      day: "numeric",
    })}.`,
    link: `/edit/${post.slug}`,
    post_id: post.id,
    read: false,
  });

  return { resolved: true, error: null, status: "pending_revision" as const };
}
