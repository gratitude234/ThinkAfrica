import type { PostType } from "@/lib/utils";

export type VerificationType =
  | "student"
  | "researcher"
  | "faculty"
  | "institution";

export type AppRole = "student" | "reviewer" | "editor" | "admin";

export type PostStatus =
  | "draft"
  | "pending"
  | "pending_revision"
  | "published"
  | "rejected";

export type ReviewRecommendation = "accept" | "revise" | "reject";

export type ReferenceType = "journal" | "book" | "website" | "report" | "other";

export interface ProfileSummary {
  id: string;
  username: string;
  full_name: string | null;
  university: string | null;
  avatar_url?: string | null;
  verified?: boolean;
  verified_type?: VerificationType | null;
  role?: AppRole;
}

export interface SubmissionTrack {
  post_type: PostType;
  requires_review: boolean;
  min_reviewers: number;
  allow_revision: boolean;
  description: string | null;
}

export interface PostReviewRecord {
  id: string;
  post_id: string;
  reviewer_id: string;
  round: number;
  recommendation: ReviewRecommendation | null;
  notes: string | null;
  submitted_at: string | null;
  assigned_at: string;
}

export interface PostVersionRecord {
  id: string;
  post_id: string;
  version_number: number;
  content: string;
  title: string;
  excerpt: string | null;
  author_note: string | null;
  created_at: string;
}

export interface PostAuthorRecord {
  post_id: string;
  user_id: string;
  display_order: number;
  corresponding_author: boolean;
  invited_at: string;
  accepted_at: string | null;
}

export interface AcceptedCoAuthor extends PostAuthorRecord {
  profile: ProfileSummary;
}

export interface PostReferenceRecord {
  id: string;
  post_id: string;
  display_order: number;
  ref_type: ReferenceType | null;
  authors: string | null;
  title: string;
  year: number | null;
  source: string | null;
  url: string | null;
  doi: string | null;
  raw: string | null;
}

export interface ExtendedPostRecord {
  id: string;
  author_id: string;
  title: string;
  slug: string;
  content: string | null;
  excerpt: string | null;
  type: PostType;
  status: PostStatus;
  tags: string[] | null;
  view_count?: number | null;
  created_at: string;
  published_at: string | null;
  cover_image_url?: string | null;
  current_round: number;
  citation_id: string | null;
  revision_due_at: string | null;
}

export interface PostContributorSummary extends ProfileSummary {
  corresponding_author?: boolean;
  display_order?: number;
}
