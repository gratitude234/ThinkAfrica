Continue building the ThinkAfrica platform. Phase 1 (auth, profiles, post editor, feed, single post, admin review) and Phase 2 (debates, gamification, notifications, leaderboard, search, enhanced navbar) are already built.

Now implement Phase 3: Webinars, Campus Ambassador System, Institutional Outreach Tools, and Platform Polish.

Tech stack: Next.js 14 (App Router, TypeScript, Tailwind CSS) + Supabase.
Brand colors: Primary #10B981 (emerald), Secondary #F59E0B (gold), Accent #7C3AED (purple).

---

## 1. DATABASE — Add to /supabase/schema_phase3.sql

webinars (
  id uuid PK default gen_random_uuid(),
  title text not null,
  description text,
  host_id uuid → profiles,
  status text default 'scheduled' CHECK IN ('scheduled', 'live', 'ended'),
  scheduled_at timestamptz not null,
  ended_at timestamptz,
  tags text[],
  attendee_count int default 0,
  recording_url text,
  created_at timestamptz default now()
)

webinar_attendees (
  user_id uuid → profiles,
  webinar_id uuid → webinars,
  registered_at timestamptz default now(),
  attended boolean default false,
  PRIMARY KEY (user_id, webinar_id)
)

webinar_questions (
  id uuid PK default gen_random_uuid(),
  webinar_id uuid → webinars,
  author_id uuid → profiles,
  content text not null,
  upvotes int default 0,
  answered boolean default false,
  created_at timestamptz default now()
)

campus_ambassadors (
  id uuid PK default gen_random_uuid(),
  user_id uuid → profiles unique,
  university text not null,
  status text default 'pending' CHECK IN ('pending', 'active', 'inactive'),
  referral_count int default 0,
  joined_at timestamptz default now()
)

policy_briefs_featured (
  id uuid PK default gen_random_uuid(),
  post_id uuid → posts,
  featured_by uuid → profiles,
  institution_target text,
  featured_at timestamptz default now()
)

Add RLS:
- Anyone can read scheduled/live/ended webinars
- Authenticated users can register for webinars (insert webinar_attendees)
- Authenticated users can submit webinar questions
- Only the user themselves can read their ambassador record
- Admins (by email match) can update ambassador status

---

## 2. WEBINARS FEATURE

### /app/(main)/webinars/page.tsx — Webinars Feed
- Fetch all webinars ordered by scheduled_at desc
- Show webinar cards: title, host name + avatar, scheduled date/time, status badge (Scheduled/Live/Ended), attendee count, tags
- Filter tabs: Upcoming | Live | Past
- "Host a Webinar" button (authenticated only) → /webinars/create
- "Register" button on each upcoming webinar card (toggles registration)

### /app/(main)/webinars/create/page.tsx — Create Webinar
- Protected route
- Fields: Title, Description, Scheduled Date & Time (datetime-local input), Tags
- On submit: insert into webinars with status 'scheduled'
- Redirect to the new webinar page

### /app/(main)/webinars/[id]/page.tsx — Single Webinar
- Fetch webinar + host profile + registered attendee count
- Show: title, description, host info, scheduled time, status, tags
- Register/Unregister button (updates webinar_attendees)
- Live Q&A section:
  - List questions ordered by upvotes desc
  - Submit a question (textarea, auth required, disabled if status is 'ended')
  - Upvote button per question
  - "Answered" badge on questions marked answered (host only can mark)
- If status is 'ended' and recording_url exists, show a recording link
- Use Supabase Realtime to subscribe to new questions live

---

## 3. CAMPUS AMBASSADOR PROGRAM

### /app/(main)/ambassadors/page.tsx — Ambassador Landing Page
- Hero section explaining the program benefits:
  - Represent ThinkAfrica at your university
  - Earn bonus points for referrals
  - Get featured on the platform
  - Access exclusive webinars and mentor sessions
- "Apply to Become an Ambassador" CTA (auth required)
- Grid of current active ambassadors: avatar, name, university, referral count

### /app/(main)/ambassadors/apply/page.tsx — Application Page
- Protected route
- Fields: University (pre-filled from profile), Why do you want to be an ambassador? (textarea), How will you recruit contributors? (textarea)
- On submit: insert into campus_ambassadors with status 'pending'
- Show confirmation message after applying

### /app/(main)/admin/ambassadors/page.tsx — Admin: Manage Ambassadors
- Admin only (email check)
- List all ambassador applications with status
- Approve / Reject buttons (updates status to 'active' or 'inactive')
- Show user profile info for each applicant

---

## 4. INSTITUTIONAL OUTREACH — POLICY BRIEF SPOTLIGHT

### /app/(main)/policy/page.tsx — Policy Hub
- Dedicated page for policy briefs only
- Hero: "Student-Generated Policy Ideas for Africa"
- Featured policy briefs (from policy_briefs_featured table) shown prominently at top
- All published policy_brief posts below, ordered by view_count desc
- Each card shows: title, author, university, tags, view count, excerpt
- "Submit to Institutions" button (admin only) — marks a policy brief as featured and sets institution_target

### Update /app/(main)/admin/review/page.tsx
- Add a "Feature for Institutions" button on approved policy briefs
- Opens a small modal: input for institution_target (e.g. "Federal Ministry of Education")
- On confirm: inserts into policy_briefs_featured

---

## 5. READING EXPERIENCE IMPROVEMENTS

### Update /app/(main)/post/[slug]/page.tsx
- Add estimated read time (calculate from word count: words / 200 = minutes)
- Add a sticky "Table of Contents" sidebar on desktop (extract h2/h3 headings from content)
- Add social share buttons: Twitter/X, LinkedIn, Copy Link
- Add "Related Posts" section at the bottom — fetch 3 posts with matching tags
- Add author bio card at the bottom with follow button

### /app/(main)/post/[slug]/page.tsx — Reading Progress Bar
- Thin emerald green progress bar at the very top of the page
- Fills as the user scrolls through the article
- Implemented as a client component using scroll event listener

---

## 6. ONBOARDING FLOW

### /app/(main)/onboarding/page.tsx
- Shown automatically to new users after signup (check if profile has no university set)
- Multi-step form (3 steps):
  - Step 1: Complete your profile — Full name, Username, University, Field of Study, Bio
  - Step 2: Choose your interests — tag selection grid (Law, Economics, Tech, Health, Politics, Environment, Education, Culture) — saves to a new profile_interests text[] column
  - Step 3: Welcome screen — "You're ready to think with Africa" — links to Feed, Write, Debates
- Progress indicator showing Step 1/2/3
- On completion: update profile, redirect to feed
- Skip button on Step 2 and 3

### Add to /supabase/schema_phase3.sql:
ALTER TABLE profiles ADD COLUMN IF NOT EXISTS interests text[];
ALTER TABLE profiles ADD COLUMN IF NOT EXISTS onboarding_completed boolean default false;

---

## 7. TRENDING TOPICS PAGE

### /app/(main)/topics/[tag]/page.tsx
- Dynamic route for each tag (e.g. /topics/Economics)
- Show all published posts with that tag ordered by view_count desc
- Show tag name as hero heading
- Post count for this tag
- Top 3 contributors who write about this tag

### Update PostCard component
- Make each tag in PostCard clickable → links to /topics/[tag]

---

## 8. FOOTER COMPONENT

### /components/ui/Footer.tsx
- Add a proper footer to the main layout
- Sections:
  - ThinkAfrica logo + tagline "Where Africa's Ideas Connect"
  - Platform links: Feed, Debates, Webinars, Leaderboard, Policy Hub
  - Community links: Become an Ambassador, Write for ThinkAfrica, Editorial Standards
  - Legal: Privacy Policy, Terms of Use (static placeholder pages)
- Copyright line: © 2025 ThinkAfrica. Built for Africa.
- Emerald/dark background, clean layout

---

## 9. STATIC PAGES

### /app/(main)/about/page.tsx
- About ThinkAfrica page
- Mission, vision, the problem we solve
- The team section (placeholder for now)
- A "Join the Movement" CTA linking to signup

### /app/(main)/editorial-standards/page.tsx
- Explain the 4 content types and their standards
- Quality standards table (word counts, review types)
- How the editorial review process works
- Contact email for editorial inquiries

---

## WHAT TO GENERATE
1. All new page and component files with working code
2. /supabase/schema_phase3.sql with all new tables, columns, and RLS policies
3. Supabase Realtime in webinar questions
4. Reading progress bar as a client component
5. Footer added to the main layout
6. All Supabase queries using typed client

Do not recreate Phase 1 or Phase 2 files. Only add or update what Phase 3 requires. Keep all styling consistent with the existing brand.