import type { Metadata } from "next";
import Link from "next/link";
import { notFound, redirect } from "next/navigation";
import EvidenceLegend from "@/components/profile/EvidenceLegend";
import ProfileRecordCard, { PROFILE_RECORD_LIST } from "@/components/profile/ProfileRecordCard";
import ScrollActiveIntoView from "@/components/profile/ScrollActiveIntoView";
import UserAvatar from "@/components/ui/UserAvatar";
import { FEATURE_FLAGS, isProfilePositioningEnabled } from "@/lib/featureFlags";
import { getProfileViewerState } from "@/lib/profileFunnel";
import { getProfileIdentityLines } from "@/lib/profileIdentity";
import {
  PROFILE_RECORD_FILTERS,
  buildProfileRecordHref,
  parseProfileRecordQuery,
  profileRecordFilterLabel,
  type ProfileRecordFilter,
} from "@/lib/profileRecord";
import { RECORD_SHELL } from "@/lib/profileLayout";
import {
  loadProfileRecordPage,
  loadProfileRecordSummary,
  loadProfileTopicIndex,
} from "@/lib/profileRecordData";
import { createClient } from "@/lib/supabase/server";

interface PageProps {
  params: Promise<{ username: string }>;
  searchParams: Promise<Record<string, string | string[] | undefined>>;
}

interface RecordProfile {
  id: string;
  username: string;
  full_name: string | null;
  avatar_url: string | null;
  professional_title: string | null;
  university: string | null;
  field_of_study: string | null;
  country: string | null;
  profile_type: string | null;
  organization_name: string | null;
  bio: string | null;
  interests: string[] | null;
  positioning_statement?: string | null;
  verified: boolean;
  verified_type: string | null;
  is_alumni: boolean;
}

const PROFILE_BASE_SELECT =
  "id, username, full_name, avatar_url, professional_title, university, field_of_study, country, profile_type, organization_name, bio, interests, verified, verified_type, is_alumni";

/** See the same helper on the profile page. */
function profileSelect() {
  return isProfilePositioningEnabled()
    ? `${PROFILE_BASE_SELECT}, positioning_statement`
    : PROFILE_BASE_SELECT;
}

function name(profile: RecordProfile) {
  return profile.full_name?.trim() || profile.username;
}

function contextLine(profile: RecordProfile) {
  const identity = getProfileIdentityLines(profile);
  return [identity.headline, identity.affiliation].filter(Boolean).join(" · ");
}

function firstQueryValue(value: string | string[] | undefined) {
  return Array.isArray(value) ? value[0] : value;
}

function rawRecordHref(
  username: string,
  query: Record<string, string | string[] | undefined>
) {
  const params = new URLSearchParams();
  for (const key of ["type", "quality", "topic", "page"] as const) {
    const value = firstQueryValue(query[key]);
    if (value !== undefined) params.set(key, value);
  }
  const suffix = params.toString();
  return `/${username}/record${suffix ? `?${suffix}` : ""}`;
}

export async function generateMetadata({ params, searchParams }: PageProps): Promise<Metadata> {
  const [{ username }, rawQuery] = await Promise.all([params, searchParams]);
  const supabase = await createClient();
  const { data } = await supabase
    .from("profiles")
    .select(profileSelect())
    .eq("username", username)
    .maybeSingle();
  const profile = data as RecordProfile | null;
  if (!profile) return { title: "Intellectual Record - Indegenius" };
  const query = parseProfileRecordQuery(
    {
      type: firstQueryValue(rawQuery.type),
      quality: firstQueryValue(rawQuery.quality),
      topic: firstQueryValue(rawQuery.topic),
      page: firstQueryValue(rawQuery.page),
    },
    FEATURE_FLAGS.research
  );
  const title = `${name(profile)}'s Intellectual Record`;
  const recordKinds = FEATURE_FLAGS.research
    ? "Publications, responses, research, and debate arguments"
    : "Publications, responses, and debate arguments";
  const positioning = getProfileIdentityLines(profile).positioning;
  return {
    title,
    description: positioning
      ? `${recordKinds} by ${name(profile)}. ${positioning}`
      : `${recordKinds} by ${name(profile)}.`,
    alternates: {
      canonical: buildProfileRecordHref({
        username: profile.username,
        filter: query.filter,
        quality: query.quality,
        topic: query.topic,
        page: query.page,
      }),
    },
  };
}

function filterCount(
  filter: ProfileRecordFilter,
  summary: Awaited<ReturnType<typeof loadProfileRecordSummary>>
) {
  if (filter === "publications") return summary.publicationCount;
  if (filter === "responses") return summary.responseCount;
  if (filter === "debates") return summary.debateCount;
  if (filter === "research") return summary.researchCount;
  return summary.publicationCount + summary.responseCount + summary.debateCount;
}

export default async function ProfileRecordPage({ params, searchParams }: PageProps) {
  const [{ username }, rawQuery] = await Promise.all([params, searchParams]);
  const supabase = await createClient();
  const [{ data }, { data: userData }] = await Promise.all([
    supabase.from("profiles").select(profileSelect()).eq("username", username).maybeSingle(),
    supabase.auth.getUser(),
  ]);
  const profile = data as RecordProfile | null;
  if (!profile) notFound();

  const query = parseProfileRecordQuery(
    {
      type: firstQueryValue(rawQuery.type),
      quality: firstQueryValue(rawQuery.quality),
      topic: firstQueryValue(rawQuery.topic),
      page: firstQueryValue(rawQuery.page),
    },
    FEATURE_FLAGS.research
  );
  const normalizedHref = buildProfileRecordHref({
    username: profile.username,
    filter: query.filter,
    quality: query.quality,
    topic: query.topic,
    page: query.page,
  });
  if (rawRecordHref(profile.username, rawQuery) !== normalizedHref) {
    redirect(normalizedHref);
  }
  // The summary does not depend on the topic filter, so it goes out alongside
  // the topic index rather than waiting behind it. Only the page of entries
  // needs the ids the index resolves.
  const summaryPromise = loadProfileRecordSummary(
    supabase,
    profile.id,
    FEATURE_FLAGS.research
  );
  // The index also feeds the topic filter row below, so it loads whether or
  // not a topic is active.
  const topicIndex = await loadProfileTopicIndex({
    supabase,
    profileId: profile.id,
    declaredInterests: profile.interests,
    includeResearch: FEATURE_FLAGS.research,
  });
  const topicEntryIds = query.topic
    ? topicIndex.postIdsByTopic.get(query.topic) ?? []
    : null;

  const [record, summary] = await Promise.all([
    loadProfileRecordPage({
      supabase,
      profileId: profile.id,
      filter: query.filter,
      quality: query.quality,
      page: query.page,
      includeResearch: FEATURE_FLAGS.research,
      entryIds: topicEntryIds,
    }),
    summaryPromise,
  ]);

  if (query.page > 1 && record.items.length === 0) {
    redirect(
      buildProfileRecordHref({
        username: profile.username,
        filter: query.filter,
        quality: query.quality,
        topic: query.topic,
      })
    );
  }

  const viewerState = getProfileViewerState({
    viewerId: userData.user?.id ?? null,
    profileId: profile.id,
  });
  // Every filter stays reachable by URL. A tab with nothing behind it is
  // still rendered and still navigable; it just does not advertise a zero in
  // display type next to its name, which read as a scoreboard of what this
  // author has not done.
  const filters = PROFILE_RECORD_FILTERS.filter(
    (filter) => FEATURE_FLAGS.research || filter !== "research"
  );
  const showQuality = query.filter === "publications" || query.filter === "research";
  // Tab counts describe the whole record. With a topic active they would
  // contradict the result count directly beneath them, so they come off.
  const showFilterCounts = !query.topic;
  const activeTopic = topicIndex.demonstratedTopics.find(
    (topic) => topic.key === query.topic
  );
  const activeTopicLabel = activeTopic?.label ?? query.topic;
  // A topic typed straight into the URL still gets a chip, so the row always
  // shows what is filtering the list rather than looking unfiltered.
  const topicChips =
    query.topic && !activeTopic
      ? [
          { key: query.topic, label: activeTopicLabel ?? query.topic, count: 0 },
          ...topicIndex.demonstratedTopics,
        ]
      : topicIndex.demonstratedTopics;

  return (
    <div className={`${RECORD_SHELL} space-y-6`}>
      <header className="rounded-xl border border-card-border bg-card p-5 sm:p-6">
        <Link
          href={`/${profile.username}`}
          className="tap-target focus-ring text-sm font-semibold text-emerald-ink hover:underline"
        >
          ← Back to profile
        </Link>
        <div className="mt-3 flex items-center gap-3">
          <UserAvatar name={name(profile)} src={profile.avatar_url} size={52} />
          <div className="min-w-0">
            <h1 className="font-display text-2xl font-semibold text-ink sm:text-3xl">
              {name(profile)}&apos;s Intellectual Record
            </h1>
            <p className="mt-1 text-sm text-ink-muted">{contextLine(profile)}</p>
          </div>
        </div>
      </header>

      <section aria-label="Record filters" className="space-y-3">
        <ScrollActiveIntoView className="scroll-hint-x flex overflow-x-auto border-b border-card-border [scrollbar-width:none] [&::-webkit-scrollbar]:hidden">
          {filters.map((filter) => {
            const active = query.filter === filter;
            return (
              <Link
                key={filter}
                href={buildProfileRecordHref({ username: profile.username, filter, topic: query.topic })}
                aria-current={active ? "page" : undefined}
                className={`focus-ring -mb-px inline-flex min-h-11 shrink-0 items-center border-b-2 px-4 text-sm font-semibold ${
                  active
                    ? "border-emerald-brand text-ink"
                    : "border-transparent text-ink-muted hover:text-ink"
                }`}
              >
                {profileRecordFilterLabel(filter)}
                {showFilterCounts && filterCount(filter, summary) > 0 ? (
                  <span className="ml-1.5 text-xs font-normal text-ink-muted">
                    {filterCount(filter, summary).toLocaleString()}
                  </span>
                ) : null}
              </Link>
            );
          })}
        </ScrollActiveIntoView>

        {/* The row keeps its height on every tab. It used to appear only for
            Publications and Research, so moving between filters inserted or
            removed 40px and jumped every card below it, arriving after a route
            transition where it read as a rendering fault. */}
        <div className="flex min-h-[40px] flex-wrap items-center gap-2" aria-label="Evidence filters">
          {showQuality
            ? ([
                ["all", "All evidence"],
                ["source_backed", "Source-backed"],
                ["citable", "Citable"],
              ] as const).map(([quality, label]) => (
                <Link
                  key={quality}
                  href={buildProfileRecordHref({
                    username: profile.username,
                    filter: query.filter,
                    quality,
                    topic: query.topic,
                  })}
                  aria-current={query.quality === quality ? "page" : undefined}
                  className={`tap-target focus-ring inline-flex items-center rounded-full border px-3 py-1.5 text-xs font-semibold ${
                    query.quality === quality
                      ? "border-emerald-brand bg-green-tint text-emerald-brand"
                      : "border-card-border bg-card text-ink-muted hover:text-ink"
                  }`}
                >
                  {label}
                </Link>
              ))
            : null}
        </div>

        {/* Type and evidence are the platform's categories. Topic is the
            reader's: someone who came for this author's poetry cannot get to
            it from the two rows above. */}
        {topicChips.length > 0 ? (
          <ScrollActiveIntoView
            className="scroll-hint-x flex gap-2 overflow-x-auto pb-1 [scrollbar-width:none] [&::-webkit-scrollbar]:hidden"
            label="Topic filters"
          >
            <Link
              href={buildProfileRecordHref({
                username: profile.username,
                filter: query.filter,
                quality: query.quality,
              })}
              aria-current={query.topic ? undefined : "page"}
              className={`tap-target focus-ring inline-flex shrink-0 items-center rounded-full border px-3 py-1.5 text-xs font-semibold ${
                query.topic
                  ? "border-card-border bg-card text-ink-muted hover:text-ink"
                  : "border-emerald-brand bg-green-tint text-emerald-brand"
              }`}
            >
              All topics
            </Link>
            {topicChips.map((topic) => {
              const active = topic.key === query.topic;
              return (
                <Link
                  key={topic.key}
                  href={buildProfileRecordHref({
                    username: profile.username,
                    filter: query.filter,
                    quality: query.quality,
                    topic: topic.key,
                  })}
                  aria-current={active ? "page" : undefined}
                  aria-label={
                    topic.count > 0
                      ? `Filter by ${topic.label}, ${topic.count} ${
                          topic.count === 1 ? "entry" : "entries"
                        }`
                      : `Filter by ${topic.label}`
                  }
                  className={`tap-target focus-ring inline-flex shrink-0 items-center gap-1.5 rounded-full border px-3 py-1.5 text-xs font-semibold ${
                    active
                      ? "border-emerald-brand bg-green-tint text-emerald-brand"
                      : "border-card-border bg-card text-ink-muted hover:text-ink"
                  }`}
                >
                  {topic.label}
                  {topic.count > 0 ? (
                    <span aria-hidden="true" className="font-normal tabular-nums opacity-70">
                      {topic.count}
                    </span>
                  ) : null}
                </Link>
              );
            })}
          </ScrollActiveIntoView>
        ) : null}
      </section>

      <div className="flex items-center justify-between gap-4">
        <p className="text-sm text-ink-muted">
          {record.totalCount.toLocaleString()} result{record.totalCount === 1 ? "" : "s"}
        </p>
        <EvidenceLegend />
      </div>

      {record.items.length > 0 ? (
        <div className={PROFILE_RECORD_LIST}>
          {record.items.map((item) => (
            <ProfileRecordCard
              key={`${item.kind}-${item.id}`}
              item={item}
              tracking={{
                profileId: profile.id,
                viewerState,
                surface: "full_record",
              }}
            />
          ))}
        </div>
      ) : (
        <div className="rounded-xl border border-dashed border-card-border bg-card p-8 text-center">
          <h2 className="font-display text-xl font-semibold text-ink">Nothing here yet</h2>
          <p className="mt-2 text-sm text-ink-muted">
            {activeTopicLabel
              ? `${name(profile)} has no public entries tagged ${activeTopicLabel}.`
              : "This part of the Intellectual Record has no public entries."}
          </p>
          {activeTopicLabel ? (
            <Link
              href={buildProfileRecordHref({
                username: profile.username,
                filter: query.filter,
                quality: query.quality,
              })}
              className="tap-target focus-ring mt-3 inline-block text-sm font-semibold text-emerald-ink hover:underline"
            >
              Show all topics
            </Link>
          ) : null}
        </div>
      )}

      {record.hasPreviousPage || record.hasNextPage ? (
        <nav aria-label="Record pages" className="flex items-center justify-between border-t border-card-border pt-4">
          {record.hasPreviousPage ? (
            <Link
              href={buildProfileRecordHref({
                username: profile.username,
                filter: query.filter,
                quality: query.quality,
                topic: query.topic,
                page: query.page - 1,
              })}
              className="focus-ring inline-flex min-h-11 items-center rounded-lg border border-card-border bg-card px-4 text-sm font-semibold text-ink-soft hover:border-card-border-hover hover:text-ink"
            >
              ← Previous
            </Link>
          ) : <span />}
          <span className="text-xs text-ink-muted">Page {query.page}</span>
          {record.hasNextPage ? (
            <Link
              href={buildProfileRecordHref({
                username: profile.username,
                filter: query.filter,
                quality: query.quality,
                topic: query.topic,
                page: query.page + 1,
              })}
              className="focus-ring inline-flex min-h-11 items-center rounded-lg border border-card-border bg-card px-4 text-sm font-semibold text-ink-soft hover:border-card-border-hover hover:text-ink"
            >
              Next →
            </Link>
          ) : <span />}
        </nav>
      ) : null}
    </div>
  );
}
