import { redirect } from "next/navigation";
import { createAdminActionClient } from "@/lib/adminAccess";
import { RESEARCH_TYPE_QUERY_EXCLUSION } from "@/lib/featureFlags";
import { AdminAccessError, createAdminClient } from "@/lib/supabase/admin";
import Badge from "@/components/ui/Badge";
import Tag from "@/components/ui/Tag";
import { formatDate } from "@/lib/utils";
import ReviewActions from "./ReviewActions";
import FeaturePolicyButton from "@/app/(main)/policy/FeaturePolicyButton";
import FeaturePostButton from "./FeaturePostButton";
import AssignReviewers from "./AssignReviewers";
import { requiresEditorialWorkflow } from "@/lib/reviewWorkflow";
import { isFormallyReviewed } from "@/lib/contentModel";
import { getPostQualitySummary } from "@/lib/postQuality";
import { getEditorialTrustSummary } from "@/lib/editorialTrust";
import { getProfileCredibilitySummary } from "@/lib/profileCredibility";

type ReviewerAssignment = {
  post_id: string;
  reviewer_id: string;
  submitted_at: string | null;
  recommendation: string | null;
  notes: string | null;
  round: number;
  reviewer: {
    id: string;
    username: string;
    full_name: string | null;
  } | null;
};

function getBlockingReason(
  requiresReview: boolean,
  minReviewers: number,
  assignments: ReviewerAssignment[]
) {
  if (!requiresReview) {
    return null;
  }

  if (assignments.length < minReviewers) {
    return `Assign at least ${minReviewers} reviewer${minReviewers === 1 ? "" : "s"} before making a decision.`;
  }

  if (assignments.some((assignment) => !assignment.submitted_at || !assignment.recommendation)) {
    return "Wait for every assigned reviewer to submit a recommendation.";
  }

  return null;
}

function getReviewSummary(assignments: ReviewerAssignment[]) {
  const completed = assignments.filter((assignment) => assignment.submitted_at && assignment.recommendation);
  if (completed.length === 0) {
    return null;
  }

  const counts = completed.reduce(
    (acc, assignment) => {
      const key = assignment.recommendation as "accept" | "revise" | "reject";
      acc[key] += 1;
      return acc;
    },
    { accept: 0, revise: 0, reject: 0 }
  );

  return `Accept ${counts.accept} / Revise ${counts.revise} / Reject ${counts.reject}`;
}

export default async function AdminReviewPage() {
  let admin: ReturnType<typeof createAdminClient> | null = null;
  try {
    const result = await createAdminActionClient("editorial.manage");
    admin = result.admin;
  } catch (error) {
    if (error instanceof AdminAccessError && error.status === 401) redirect("/login");
    return (
      <div className="mx-auto max-w-2xl py-20 text-center">
        <p className="text-gray-500">You don&apos;t have access to this page.</p>
      </div>
    );
  }

  const [
    { data: pendingPostsRaw },
    { data: publishedPostsRaw },
    { data: featuredIdsRaw },
    { data: tracksRaw },
    { data: reviewersRaw },
    { data: reviewsRaw },
    { data: decisionsRaw },
    { data: versionsRaw },
  ] = await Promise.all([
    admin
      .from("posts")
      .select(
        `
        id, title, excerpt, content, type, status, tags, created_at, author_id, current_round,
        document_path, document_original_name, document_size_bytes,
        citation_id, published_version_id,
        post_references(id),
        profiles!posts_author_id_fkey (username, full_name, university, field_of_study, verified, verified_type)
      `
      )
      .eq("status", "pending")
      .neq("type", RESEARCH_TYPE_QUERY_EXCLUSION)
      .order("created_at", { ascending: false })
      .limit(50),
    admin
      .from("posts")
      .select(
        `id, title, excerpt, type, featured, created_at,
        profiles!posts_author_id_fkey (full_name, university)`
      )
      .eq("status", "published")
      .neq("type", RESEARCH_TYPE_QUERY_EXCLUSION)
      .order("published_at", { ascending: false })
      .limit(20),
    admin.from("policy_briefs_featured").select("post_id"),
    admin.from("submission_tracks").select("*"),
    admin
      .from("profiles")
      .select("id, username, full_name, university, field_of_study, role")
      .in("role", ["reviewer", "editor", "admin"]),
    admin
      .from("post_reviews")
      .select(
        "post_id, reviewer_id, submitted_at, recommendation, notes, round, reviewer:profiles!post_reviews_reviewer_id_fkey(id, username, full_name)"
      )
      .is("removed_at", null)
      .order("assigned_at", { ascending: true }),
    admin
      .from("post_editor_decisions")
      .select(
        "post_id, round, decision, notes, created_at, editor:profiles!post_editor_decisions_editor_id_fkey(username, full_name)"
      )
      .order("created_at", { ascending: false }),
    admin
      .from("post_versions")
      .select("post_id, id, version_kind, round, created_at")
      .order("created_at", { ascending: true }),
  ]);

  const posts = (pendingPostsRaw ?? []).map((post) => ({
    ...post,
    profiles: Array.isArray(post.profiles) ? post.profiles[0] : post.profiles,
  }));

  const tracks = new Map((tracksRaw ?? []).map((track) => [track.post_type, track]));
  const groupedPosts = posts.reduce(
    (acc, post) => {
      const group = acc.get(post.type) ?? [];
      group.push(post);
      acc.set(post.type, group);
      return acc;
    },
    new Map<string, typeof posts>()
  );

  const publishedPosts = (publishedPostsRaw ?? []).map((post) => ({
    ...post,
    featured: (post as { featured?: boolean }).featured ?? false,
    profiles: Array.isArray(post.profiles) ? post.profiles[0] : post.profiles,
  }));

  const alreadyFeatured = new Set((featuredIdsRaw ?? []).map((item) => item.post_id));

  const { data: policyBriefsRaw } = await admin
    .from("posts")
    .select(
      "id, title, excerpt, tags, created_at, profiles!posts_author_id_fkey (full_name, university)"
    )
    .eq("status", "published")
    .eq("type", "policy_brief")
    .order("created_at", { ascending: false });

  const policyBriefs = (policyBriefsRaw ?? [])
    .filter((post) => !alreadyFeatured.has(post.id))
    .map((post) => ({
      ...post,
      profiles: Array.isArray(post.profiles) ? post.profiles[0] : post.profiles,
    }));

  return (
    <div className="mx-auto max-w-5xl">
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-gray-900">Editorial Queue</h1>
        <p className="mt-1 text-sm text-gray-500">
          Track reviewed submissions from assignment through final editor decision.
        </p>
      </div>

      {posts.length === 0 ? (
        <div className="py-16 text-center text-gray-400">
          <p className="text-lg font-medium">No submissions waiting in the editorial queue.</p>
          <p className="mt-1 text-sm text-gray-400">
            Policy briefs will appear here once submitted.
          </p>
        </div>
      ) : (
        <div className="space-y-8">
          {Array.from(groupedPosts.entries()).map(([type, typePosts]) => {
            const track = tracks.get(type);

            return (
              <section key={type} className="space-y-4">
                <div>
                  <h2 className="text-lg font-semibold capitalize text-gray-900">
                    {type.replace("_", " ")}
                  </h2>
                  {track?.description ? (
                    <p className="mt-1 text-sm text-gray-500">{track.description}</p>
                  ) : null}
                </div>

                {typePosts.map((post) => {
                  const currentRound = post.current_round ?? 1;
                  const assignments = ((reviewsRaw ?? []) as unknown as ReviewerAssignment[])
                    .filter(
                      (review) => review.post_id === post.id && review.round === currentRound
                    )
                    .map((review) => ({
                      ...review,
                      reviewer: Array.isArray(review.reviewer)
                        ? review.reviewer[0]
                        : review.reviewer,
                    }));

                  const latestDecision = (decisionsRaw ?? []).find(
                    (decision) =>
                      decision.post_id === post.id && decision.round < currentRound
                  );
                  const decisions = (decisionsRaw ?? []).filter(
                    (decision) => decision.post_id === post.id
                  );
                  const versions = (versionsRaw ?? []).filter(
                    (version) => version.post_id === post.id
                  );

                  const availableReviewers = ((reviewersRaw ?? []) as Array<{
                    id: string;
                    username: string;
                    full_name: string | null;
                    university: string | null;
                    field_of_study: string | null;
                  }>).filter((reviewer) => reviewer.id !== post.author_id);

                  const reviewSummary = getReviewSummary(assignments);
                  const blockingReason = getBlockingReason(
                    Boolean(track?.requires_review),
                    track?.min_reviewers ?? 0,
                    assignments
                  );
                  const readyForDecision = !blockingReason;
                  const referenceCount =
                    (
                      post as typeof post & {
                        post_references?: Array<{ id: string }>;
                      }
                    ).post_references?.length ?? 0;
                  const qualitySummary = getPostQualitySummary({
                    type: post.type,
                    status: post.status,
                    title: post.title,
                    excerpt: post.excerpt,
                    content: post.content,
                    tags: post.tags ?? [],
                    author: post.profiles,
                    referenceCount,
                    reviewCount: assignments.length,
                    completedReviewCount: assignments.filter(
                      (assignment) => assignment.submitted_at
                    ).length,
                  });
                  const editorialSummary = getEditorialTrustSummary({
                    type: post.type,
                    status: post.status,
                    currentRound,
                    createdAt: post.created_at,
                    referenceCount,
                    minReviewers: track?.min_reviewers ?? 0,
                    requiresReview: Boolean(track?.requires_review),
                    reviews: assignments,
                    decisions,
                    versionCount: versions.length,
                  });
                  const credibilitySummary = getProfileCredibilitySummary({
                    profile: post.profiles,
                    stats: {
                      // Evidence-based, not name-based: every post in this
                      // queue is still pending/pending_revision/rejected by
                      // definition, so it can never itself have completed
                      // review yet regardless of type/genre --
                      // isFormallyReviewed() (citation_id/
                      // published_version_id) correctly reflects that,
                      // where requiresEditorialWorkflow(post.type) would
                      // wrongly report 1 for every research/policy_brief
                      // submission shown here, reviewed or not.
                      reviewedCount: isFormallyReviewed(post) ? 1 : 0,
                    },
                  });

                  return (
                    <div
                      key={post.id}
                      className="rounded-xl border border-gray-200 bg-white p-6"
                    >
                      <div className="flex flex-col gap-5 lg:flex-row lg:items-start lg:justify-between">
                        <div className="min-w-0 flex-1 space-y-4">
                          <div>
                            <div className="mb-2 flex flex-wrap items-center gap-2">
                              <Badge type={post.type} />
                              {requiresEditorialWorkflow(post.type) ? (
                                <span className="rounded-full border border-sky-200 bg-sky-50 px-2 py-0.5 text-xs font-medium text-sky-700">
                                  Editorial workflow required
                                </span>
                              ) : null}
                              {qualitySummary.requiresReferences && referenceCount === 0 ? (
                                <span className="rounded-full border border-amber-200 bg-amber-50 px-2 py-0.5 text-xs font-medium text-amber-700">
                                  Missing references
                                </span>
                              ) : (
                                <span className="rounded-full border border-emerald-200 bg-emerald-50 px-2 py-0.5 text-xs font-medium text-emerald-700">
                                  Quality checks clear
                                </span>
                              )}
                              {post.tags?.slice(0, 3).map((tag: string) => (
                                <Tag key={tag} label={tag} />
                              ))}
                            </div>

                            <h3 className="text-base font-semibold text-gray-900">{post.title}</h3>
                            {post.excerpt ? (
                              <p className="mt-2 line-clamp-2 text-sm text-gray-500">
                                {post.excerpt}
                              </p>
                            ) : null}
                            {post.type === "research" ? (
                              <div className="mt-3 rounded-lg border border-purple-100 bg-purple-50 px-3 py-3">
                                <p className="text-xs font-semibold uppercase tracking-wide text-purple-700">
                                  Research PDF
                                </p>
                                <p className="mt-1 text-sm font-medium text-gray-900">
                                  {(post as { document_original_name?: string | null })
                                    .document_original_name ?? "Uploaded research paper"}
                                </p>
                                {(post as { document_path?: string | null }).document_path ? (
                                  <a
                                    href={`/api/research-document/${post.id}`}
                                    target="_blank"
                                    rel="noreferrer"
                                    className="mt-2 inline-flex rounded-lg bg-purple-700 px-3 py-1.5 text-xs font-semibold text-white hover:bg-purple-800"
                                  >
                                    Open PDF
                                  </a>
                                ) : (
                                  <p className="mt-1 text-xs text-amber-700">
                                    Missing PDF
                                  </p>
                                )}
                              </div>
                            ) : null}
                            <div className="mt-3 flex flex-wrap items-center gap-2 text-xs text-gray-400">
                              <span>
                                By{" "}
                                <span className="font-medium text-gray-600">
                                  {post.profiles?.full_name}
                                </span>{" "}
                                / {post.profiles?.university}
                              </span>
                              <span>/</span>
                              <span>Submitted {formatDate(post.created_at)}</span>
                              <span>/</span>
                              <span>Round {currentRound}</span>
                              {track?.requires_review ? (
                                <>
                                  <span>/</span>
                                  <span>
                                    {assignments.filter((assignment) => assignment.submitted_at).length}/
                                    {track.min_reviewers} required reviews complete
                                  </span>
                                </>
                              ) : null}
                            </div>
                          </div>

                          {latestDecision ? (
                            <div className="rounded-lg border border-gray-200 bg-gray-50 px-4 py-3">
                              <p className="text-xs font-semibold uppercase tracking-wide text-gray-600">
                                Previous round decision
                              </p>
                              <p className="mt-1 text-sm font-medium text-gray-900">
                                Round {latestDecision.round}: {latestDecision.decision.replace("_", " ")}
                              </p>
                              {latestDecision.notes ? (
                                <p className="mt-1 text-sm text-gray-600">{latestDecision.notes}</p>
                              ) : null}
                            </div>
                          ) : null}

                          <div className="rounded-lg border border-sky-100 bg-sky-50/70 px-4 py-3">
                            <p className="text-xs font-semibold uppercase tracking-wide text-sky-700">
                              Review context
                            </p>
                            <div className="mt-3 grid gap-2 text-sm text-sky-950/80 sm:grid-cols-2">
                              <span>
                                Author: {credibilitySummary.strongestSignal ?? "Profile basics only"}
                              </span>
                              <span>
                                Sources: {referenceCount} reference{referenceCount === 1 ? "" : "s"}
                              </span>
                              <span>
                                Status: {editorialSummary.currentStatusLabel}
                              </span>
                              <span>
                                Round {editorialSummary.reviewRound} /{" "}
                                {editorialSummary.revisionCount} revision
                                {editorialSummary.revisionCount === 1 ? "" : "s"}
                              </span>
                              <span>
                                {editorialSummary.decisionContext.timeInReviewLabel ??
                                  `Submitted ${formatDate(post.created_at)}`}
                              </span>
                              <span>
                                {editorialSummary.decisionContext.readyForDecision
                                  ? "Ready for editor decision"
                                  : editorialSummary.nextActionLabel}
                              </span>
                            </div>
                          </div>

                          {assignments.some((assignment) => assignment.notes) ? (
                            <div className="space-y-2">
                              <p className="text-xs font-semibold uppercase tracking-wide text-gray-500">
                                Current round reviewer notes
                              </p>
                              {assignments
                                .filter((assignment) => assignment.notes)
                                .map((assignment) => (
                                  <div
                                    key={`${assignment.reviewer_id}-${assignment.round}`}
                                    className="rounded-lg border border-gray-100 bg-gray-50 px-4 py-3"
                                  >
                                    <div className="flex items-center justify-between gap-3">
                                      <span className="text-sm font-medium text-gray-900">
                                        {assignment.reviewer?.full_name ??
                                          assignment.reviewer?.username ??
                                          "Reviewer"}
                                      </span>
                                      <span className="text-xs font-semibold uppercase tracking-wide text-gray-500">
                                        {assignment.recommendation ?? "Awaiting"}
                                      </span>
                                    </div>
                                    <p className="mt-2 whitespace-pre-line text-sm leading-relaxed text-gray-600">
                                      {assignment.notes}
                                    </p>
                                  </div>
                                ))}
                            </div>
                          ) : null}
                        </div>

                        <div className="w-full space-y-3 lg:w-[360px]">
                          {track?.requires_review ? (
                            <AssignReviewers
                              postId={post.id}
                              round={currentRound}
                              minReviewers={track.min_reviewers}
                              reviewers={availableReviewers}
                              assignments={assignments}
                              authorFieldOfStudy={post.profiles?.field_of_study ?? null}
                              authorUniversity={post.profiles?.university ?? null}
                            />
                          ) : null}

                          <ReviewActions
                            postId={post.id}
                            requiresEditorialWorkflow={Boolean(track?.requires_review)}
                            readyForDecision={readyForDecision}
                            blockingReason={blockingReason}
                            currentRound={currentRound}
                            reviewSummary={reviewSummary}
                          />
                        </div>
                      </div>
                    </div>
                  );
                })}
              </section>
            );
          })}
        </div>
      )}

      {policyBriefs.length > 0 ? (
        <div className="mt-12">
          <div className="mb-4">
            <h2 className="text-lg font-bold text-gray-900">
              Policy Briefs - Feature for Institutions
            </h2>
            <p className="mt-0.5 text-sm text-gray-500">
              {policyBriefs.length} published brief
              {policyBriefs.length !== 1 ? "s" : ""} available to feature
            </p>
          </div>
          <div className="space-y-3">
            {policyBriefs.map((post) => (
              <div key={post.id} className="rounded-xl border border-gray-200 bg-white p-5">
                <div className="flex items-start justify-between gap-4">
                  <div className="min-w-0 flex-1">
                    <div className="mb-1 flex flex-wrap items-center gap-2">
                      {post.tags?.slice(0, 3).map((tag: string) => (
                        <Tag key={tag} label={tag} />
                      ))}
                    </div>
                    <h3 className="text-sm font-semibold text-gray-900">{post.title}</h3>
                    {post.excerpt ? (
                      <p className="mt-0.5 line-clamp-1 text-xs text-gray-500">
                        {post.excerpt}
                      </p>
                    ) : null}
                    <p className="mt-1 text-xs text-gray-400">
                      By {post.profiles?.full_name} / {post.profiles?.university}
                    </p>
                  </div>
                  <div className="flex-shrink-0">
                    <FeaturePolicyButton postId={post.id} />
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      ) : null}

      {publishedPosts.length > 0 ? (
        <div className="mt-12">
          <div className="mb-4">
            <h2 className="text-lg font-bold text-gray-900">Feature a Post</h2>
            <p className="mt-0.5 text-sm text-gray-500">
              One post can be featured on the home feed at a time. Only one is active.
            </p>
          </div>
          <div className="space-y-3">
            {publishedPosts.map((post) => (
              <div
                key={post.id}
                className={`rounded-xl border bg-white p-5 ${
                  post.featured ? "border-amber-300 bg-amber-50/40" : "border-gray-200"
                }`}
              >
                <div className="flex items-start justify-between gap-4">
                  <div className="min-w-0 flex-1">
                    <div className="mb-1 flex items-center gap-2">
                      <Badge type={post.type} />
                      {post.featured ? (
                        <span className="text-xs font-medium text-amber-600">
                          Currently featured
                        </span>
                      ) : null}
                    </div>
                    <h3 className="text-sm font-semibold text-gray-900">{post.title}</h3>
                    {post.excerpt ? (
                      <p className="mt-0.5 line-clamp-1 text-xs text-gray-500">
                        {post.excerpt}
                      </p>
                    ) : null}
                    <p className="mt-1 text-xs text-gray-400">
                      By {post.profiles?.full_name} / {post.profiles?.university}
                    </p>
                  </div>
                  <div className="flex-shrink-0">
                    <FeaturePostButton
                      postId={post.id}
                      initialFeatured={post.featured}
                    />
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      ) : null}
    </div>
  );
}
