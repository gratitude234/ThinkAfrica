import Link from "next/link";
import { createClient } from "@/lib/supabase/server";
import UserAvatar from "@/components/ui/UserAvatar";
import AuthorRelationshipControls from "@/components/profile/AuthorRelationshipControls";
import ReportButton from "@/components/moderation/ReportButton";
import BackLink from "@/components/ui/BackLink";
import PostImage from "@/components/post/PostImage";
import type { PostCardData } from "@/components/post/PostCard";
import PublishedToast from "./PublishedToast";
import PostActionsRow from "./PostActionsRow";
import DiscussionSection from "./DiscussionSection";
import { getPostDisplayTitle, getPostMetadataTitle } from "@/lib/postDisplay";
import { formatRelativeTime } from "@/lib/utils";

interface ConversationAuthor {
  id: string;
  username: string;
  full_name: string | null;
  university: string | null;
  avatar_url: string | null;
}

interface ConversationPost {
  id: string;
  slug: string;
  title: string | null;
  type: string;
  status: string;
  created_at: string;
  published_at: string | null;
  cover_image_url: string | null;
  tags: string[] | null;
  in_response_to: string | null;
}

interface ConversationSecondary {
  likeCount: number;
  responseCount: number;
  responseCards: PostCardData[];
  responsesHasMore: boolean;
  commentCount: number;
  references: Array<{
    id: string;
    title: string | null;
    authors: string | null;
    year: number | null;
    source: string | null;
    doi: string | null;
    url: string | null;
  }>;
  coAuthors: Array<{
    user_id: string;
    profile: { username: string; full_name: string | null } | null;
  }>;
  relatedPosts: Array<{
    id: string;
    title: string | null;
    slug: string;
    content_kind?: string | null;
    type?: string | null;
    profiles?: { full_name: string | null; username: string | null } | null;
  }>;
}

interface ConversationViewer {
  userLiked: boolean;
  userBookmarked: boolean;
  userFollowsAuthor: boolean;
  userSubscribedToAuthor: boolean;
}

interface PostConversationViewProps {
  post: ConversationPost;
  author: ConversationAuthor | null;
  userId: string | null;
  bodyHtml: string;
  sanitizedExcerpt: string | null;
  authorName: string;
  metadataTitle: string;
  responsePages: number;
  secondaryDataPromise: Promise<ConversationSecondary>;
  viewerDataPromise: Promise<ConversationViewer>;
}

async function ParentContextLine({ parentPostId }: { parentPostId: string }) {
  const supabase = await createClient();
  const { data: parent } = await supabase
    .from("posts")
    .select("title, slug, content_kind, type, profiles!posts_author_id_fkey (full_name, username)")
    .eq("id", parentPostId)
    .eq("status", "published")
    .maybeSingle();

  if (!parent) return null;

  // The author is right there in the row; "this post" named nobody and nothing.
  const parentProfile = Array.isArray(parent.profiles)
    ? (parent.profiles[0] ?? null)
    : (parent.profiles ?? null);

  return (
    <p className="mb-4 text-sm text-ink-muted">
      <span aria-hidden="true">↩ </span>
      Responding to{" "}
      <Link
        href={`/post/${parent.slug}`}
        className="font-semibold text-ink-soft hover:text-emerald-brand hover:underline"
      >
        {getPostMetadataTitle(parent, parentProfile)}
      </Link>
    </p>
  );
}

/**
 * The detail page for a short, titleless Post — a conversation view, not a
 * publication template: content, one actions row, then the responses. The
 * article/research kinds keep their own richer templates in page.tsx.
 */
export default async function PostConversationView({
  post,
  author,
  userId,
  bodyHtml,
  sanitizedExcerpt,
  authorName,
  metadataTitle,
  responsePages,
  secondaryDataPromise,
  viewerDataPromise,
}: PostConversationViewProps) {
  const [secondary, viewer] = await Promise.all([
    secondaryDataPromise,
    viewerDataPromise,
  ]);
  const isPublished = post.status === "published";
  const isOwnPost = Boolean(userId && author && userId === author.id);
  const relatedPost = secondary.relatedPosts[0] ?? null;
  const displayTitle = getPostDisplayTitle(post);
  const topics = post.tags ?? [];

  return (
    <div className="mx-auto max-w-[640px] pb-20">
      <PublishedToast
        postId={post.id}
        postType={post.type}
        title={metadataTitle}
        slug={post.slug}
        username={author?.username ?? ""}
        relatedTarget={
          relatedPost
            ? {
                id: relatedPost.id,
                // The related query already carries the author, so a titleless
                // Post is nameable rather than "another post".
                title: getPostMetadataTitle(relatedPost, relatedPost.profiles),
                slug: relatedPost.slug,
              }
            : null
        }
      />

      <BackLink className="inline-flex min-h-11 items-center gap-1.5 text-sm text-ink-muted transition-colors hover:text-ink focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-gold focus-visible:ring-offset-2">
        <span aria-hidden="true">‹</span> Back
      </BackLink>

      {post.status === "draft" ? (
        <div className="mt-4 rounded-xl border border-card-border bg-canvas p-4 text-sm text-ink-soft">
          This post is a <strong>draft</strong> and is only visible to you.{" "}
          <Link href={`/edit/${post.slug}`} className="font-semibold underline">
            Edit &amp; publish
          </Link>
        </div>
      ) : null}

      {author ? (
        <div className="mt-4 flex items-start justify-between gap-4">
          <div className="flex min-w-0 items-center gap-3">
            <Link href={`/${author.username}`} className="shrink-0">
              <UserAvatar
                name={authorName}
                src={author.avatar_url}
                size={48}
                className="overflow-hidden rounded-full"
              />
            </Link>
            <div className="min-w-0">
              <Link
                href={`/${author.username}`}
                className="block truncate text-lede font-bold text-ink transition-colors hover:text-emerald-brand focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-gold focus-visible:ring-offset-2"
              >
                {authorName}
              </Link>
              {author.university ? (
                <p className="truncate text-byline leading-5 text-ink-muted">{author.university}</p>
              ) : null}
              <p className="text-meta leading-5 text-ink-muted">
                {formatRelativeTime(post.published_at ?? post.created_at)}
              </p>
              {secondary.coAuthors.length > 0 ? (
                <p className="mt-0.5 text-meta leading-5 text-ink-muted">
                  With {secondary.coAuthors.map((item) => item.profile?.full_name || `@${item.profile?.username}`).filter(Boolean).join(", ")}
                </p>
              ) : null}
            </div>
          </div>
          {isOwnPost ? null : (
            <AuthorRelationshipControls
              authorId={author.id}
              authorName={authorName}
              currentUserId={userId}
              initialFollowing={viewer.userFollowsAuthor}
              initialSubscribed={viewer.userSubscribedToAuthor}
              variant="icon"
              source="post_header"
              postId={post.id}
            />
          )}
        </div>
      ) : null}

      <div className="mt-7">
        {post.in_response_to ? (
          <ParentContextLine parentPostId={post.in_response_to} />
        ) : null}
        {/* Titleless Posts render no heading at all rather than a fabricated
            one -- but a Post that does carry a title showed it in the feed and
            nowhere here, which also left the page with no h1. */}
        {displayTitle ? (
          <h1 className="mb-3 font-display text-headline font-semibold text-ink">
            {displayTitle}
          </h1>
        ) : null}
        <div
          className="text-title text-ink [&_a]:text-emerald-brand [&_a]:underline [&_p]:my-4 [&_p:first-child]:mt-0 [&_p:last-child]:mb-0"
          dangerouslySetInnerHTML={{ __html: bodyHtml }}
        />
        {post.cover_image_url ? (
          <PostImage
            src={post.cover_image_url}
            alt="Image attached to this post"
            type={post.type}
            sizes="(max-width: 680px) calc(100vw - 32px), 640px"
            priority
            wrapperClassName="mt-5"
            className="w-full overflow-hidden rounded-xl bg-canvas"
          />
        ) : null}
        {secondary.references.length > 0 ? (
          <section className="mt-8 border-t border-divider pt-6" aria-labelledby="conversation-sources">
            <h2 id="conversation-sources" className="font-display text-lg font-semibold text-ink">Sources</h2>
            <ol className="mt-3 space-y-3 text-sm text-ink-soft">
              {secondary.references.map((reference, index) => (
                <li key={reference.id} id={`ref-${index + 1}`} className="flex gap-3">
                  <span id={`ref-id-${reference.id}`} className="sr-only" aria-hidden="true" />
                  <span className="text-ink-muted">{index + 1}.</span>
                  <span>
                    {reference.url ? (
                      <a href={reference.url} target="_blank" rel="noopener noreferrer" className="font-semibold text-emerald-brand underline-offset-2 hover:underline">{reference.title || reference.source || reference.url}</a>
                    ) : (
                      <span className="font-semibold text-ink">{reference.title || reference.source}</span>
                    )}
                    {[reference.authors, reference.source, reference.year].filter(Boolean).length > 0 ? (
                      <span className="block text-ink-muted">{[reference.authors, reference.source, reference.year].filter(Boolean).join(" · ")}</span>
                    ) : null}
                  </span>
                </li>
              ))}
            </ol>
          </section>
        ) : null}
      </div>

      <div className="mt-7">
        <PostActionsRow
          postId={post.id}
          slug={post.slug}
          title={metadataTitle}
          excerpt={sanitizedExcerpt}
          authorName={author?.full_name ?? null}
          userId={userId}
          initialLiked={viewer.userLiked}
          initialLikeCount={secondary.likeCount}
          initialBookmarked={viewer.userBookmarked}
          responseCount={secondary.responseCount}
          commentCount={secondary.commentCount}
        />
        {userId && author && !isOwnPost ? (
          <p className="mt-2 text-right">
            <ReportButton
              targetType="post"
              targetId={post.id}
              targetLabel={`"${metadataTitle}"`}
              variant="text"
              className="text-xs text-ink-muted hover:text-red-600"
            />
          </p>
        ) : null}
      </div>

      {topics.length > 0 ? (
        <div className="mt-5 flex flex-wrap gap-2">
          {topics.map((topic) => (
            <Link
              key={topic}
              href={`/topics/${encodeURIComponent(topic)}`}
              className="rounded-full border border-card-border bg-surface px-3 py-1 text-meta text-ink-soft transition-colors hover:border-emerald-brand/40 hover:text-emerald-brand focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-gold focus-visible:ring-offset-2"
            >
              #{topic}
            </Link>
          ))}
        </div>
      ) : null}

      <DiscussionSection
        postId={post.id}
        userId={userId}
        userProfileId={userId}
        responseCount={secondary.responseCount}
        responseCards={secondary.responseCards}
        responsesHasMore={secondary.responsesHasMore}
        nextResponsePage={responsePages + 1}
        isPublished={isPublished}
        commentCount={secondary.commentCount}
      />
    </div>
  );
}
