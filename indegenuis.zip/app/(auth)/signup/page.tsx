"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import {
  AuthShell,
  INPUT_STYLES,
  PRIMARY_BUTTON_STYLES,
  SECONDARY_LINK_STYLES,
} from "../AuthShell";
import { formatAuthError, isAlreadyRegisteredAuthError } from "../authMessages";
import { trackActivationEvent } from "@/lib/activationEvents";
import { createClient } from "@/lib/supabase/client";
import { useResendCooldown } from "../useResendCooldown";
import {
  resendSignupConfirmationEmail,
  sendWelcomeEmail,
  sendSignupConfirmationEmail,
} from "../accountEmailActions";
import { BRAND_PROMISE } from "@/lib/brand";

const PROOF_ITEMS = [
  "Build a public record of your ideas",
  "Publish Posts and Articles",
  "Respond, debate, and collaborate",
];

type VerificationType = "signup" | "magiclink";

const AUTH_CODE_LENGTH = 6;
const RESEND_COOLDOWN_SECONDS = 45;

function getPasswordHint(password: string) {
  if (!password) return "Use at least 6 characters.";
  if (password.length < 6) return "Add a few more characters.";
  if (password.length < 10) return "Good start. Longer passwords are stronger.";
  return "Strong enough to create your account.";
}

async function withSignupTimeout<T>(promise: Promise<T>) {
  let timeoutId: ReturnType<typeof setTimeout> | undefined;

  const timeout = new Promise<never>((_, reject) => {
    timeoutId = setTimeout(() => {
      reject(
        new Error(
          "Account creation is taking too long. Check your connection and try again."
        )
      );
    }, 20000);
  });

  try {
    return await Promise.race([promise, timeout]);
  } finally {
    if (timeoutId) clearTimeout(timeoutId);
  }
}

export default function SignupPage() {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [submitted, setSubmitted] = useState(false);
  const [canResendConfirmation, setCanResendConfirmation] = useState(false);
  const [resendLoading, setResendLoading] = useState(false);
  const [resendNotice, setResendNotice] = useState<string | null>(null);
  const [resendError, setResendError] = useState<string | null>(null);
  const resendCooldown = useResendCooldown(RESEND_COOLDOWN_SECONDS);
  const [passwordVisible, setPasswordVisible] = useState(false);
  const [verificationCode, setVerificationCode] = useState("");
  const [verificationType, setVerificationType] = useState<VerificationType>("signup");
  const [verifyLoading, setVerifyLoading] = useState(false);
  const [form, setForm] = useState({
    fullName: "",
    email: "",
    password: "",
  });

  const passwordReady = form.password.length >= 6;

  const handleChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    setForm((prev) => ({ ...prev, [event.target.name]: event.target.value }));
    if (event.target.name === "email") {
      setCanResendConfirmation(false);
      setResendNotice(null);
      setResendError(null);
    }
  };

  const handleSubmit = async (event: React.FormEvent) => {
    event.preventDefault();
    setLoading(true);
    setError(null);
    setCanResendConfirmation(false);
    setResendNotice(null);
    setResendError(null);

    const normalizedEmail = form.email.trim().toLowerCase();
    const fullName = form.fullName.trim();
    const submitSignup = () =>
      sendSignupConfirmationEmail({
        email: normalizedEmail,
        password: form.password,
        fullName,
      });

    const applyResult = (result: Awaited<ReturnType<typeof submitSignup>>) => {
      if (!result.ok) {
        setError(formatAuthError(result.error));
        setCanResendConfirmation(isAlreadyRegisteredAuthError(result.error));
        setLoading(false);
        return;
      }

      setVerificationType(result.type);
      setVerificationCode("");
      resendCooldown.start();
      trackActivationEvent({ event: "signup_completed" });
      setSubmitted(true);
      setLoading(false);
    };

    try {
      applyResult(await withSignupTimeout(submitSignup()));
    } catch {
      // The client gave up waiting, not the server: withSignupTimeout races
      // a local timer against the request, it doesn't cancel it, so the
      // account may already exist by now even though this looks like a
      // failure. Follow up with another attempt instead of dead-ending on
      // an error: if the account was already created, the fallback inside
      // sendGeneratedConfirmationEmail reissues a fresh code instead of
      // erroring, so this resolves cleanly whether the first attempt
      // succeeded, is still running, or never went through at all.
      try {
        applyResult(await withSignupTimeout(submitSignup()));
      } catch (followUpError) {
        console.error("Signup failed", followUpError);
        setError(
          "Account creation is taking longer than expected. Check your email for a code before trying again, it may already have arrived."
        );
        setCanResendConfirmation(true);
        setLoading(false);
      }
    }
  };

  const handleResendConfirmation = async () => {
    if (resendCooldown.remaining > 0) return;

    setResendLoading(true);
    setResendNotice(null);
    setResendError(null);

    try {
      const result = await resendSignupConfirmationEmail({
        email: form.email.trim(),
        fullName: form.fullName,
      });

      if (result.ok) {
        setVerificationType(result.type);
        setVerificationCode("");
        setSubmitted(true);
        setResendNotice("A fresh verification code is on its way.");
        resendCooldown.start();
      } else {
        setResendError(formatAuthError(result.error));
      }
    } catch (error) {
      setResendError(
        error instanceof Error
          ? formatAuthError(error.message)
          : "We could not resend the verification code. Please try again."
      );
    } finally {
      setResendLoading(false);
    }
  };

  const handleVerifyCode = async () => {
    if (verificationCode.length !== AUTH_CODE_LENGTH || verifyLoading) return;

    setVerifyLoading(true);
    setResendError(null);
    setResendNotice(null);

    const supabase = createClient();
    const { error: verifyError } = await supabase.auth.verifyOtp({
      email: form.email.trim().toLowerCase(),
      token: verificationCode,
      type: verificationType,
    });

    if (verifyError) {
      setVerifyLoading(false);
      setResendError(formatAuthError(verifyError.message));
      return;
    }

    try {
      await sendWelcomeEmail({
        email: form.email.trim(),
        fullName: form.fullName,
      });
    } catch (welcomeEmailError) {
      console.error("Welcome email failed", welcomeEmailError);
    }

    window.location.href = "/onboarding";
  };

  useEffect(() => {
    if (verificationCode.length === AUTH_CODE_LENGTH && !verifyLoading) {
      void handleVerifyCode();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [verificationCode]);

  return (
    <AuthShell
      eyebrow="Create your profile"
      title={BRAND_PROMISE}
      subtitle="Start with your name and email. Next, choose your role, topics, and people to follow."
      proofItems={PROOF_ITEMS}
      quote="Turn what you think, write, argue, and research into a record others can explore."
      quoteSource="The Indegenius promise"
      footer={
        <>
          Already have an account?{" "}
          <Link href="/login" className={SECONDARY_LINK_STYLES}>
            Sign in
          </Link>
        </>
      }
    >
      {submitted ? (
        <div
          className="rounded-2xl border border-emerald-200 bg-emerald-50 px-5 py-5 text-sm leading-6 text-emerald-900"
          role="status"
          aria-live="polite"
        >
          <p>We sent a 6-digit code to {form.email.trim()}. Enter it below to continue.</p>
          <form
            onSubmit={(event) => {
              event.preventDefault();
              void handleVerifyCode();
            }}
            className="mt-4 space-y-3"
          >
            <div>
              <label
                htmlFor="verificationCode"
                className="mb-2 block text-sm font-semibold text-emerald-950"
              >
                Verification code
              </label>
              <input
                id="verificationCode"
                value={verificationCode}
                onChange={(event) =>
                  setVerificationCode(
                    event.target.value.replace(/\D/g, "").slice(0, AUTH_CODE_LENGTH)
                  )
                }
                inputMode="numeric"
                autoComplete="one-time-code"
                placeholder="123456"
                autoFocus
                disabled={verifyLoading}
                className={`${INPUT_STYLES} bg-white text-center text-lg font-semibold tracking-[0.3em] disabled:opacity-70`}
              />
            </div>
            {verifyLoading ? <p className="text-emerald-800">Verifying...</p> : null}
            {resendError ? <p className="text-red-700">{resendError}</p> : null}
            {resendNotice ? <p className="text-emerald-800">{resendNotice}</p> : null}
          </form>
          <button
            type="button"
            onClick={handleResendConfirmation}
            disabled={resendLoading || resendCooldown.remaining > 0 || !form.email.trim()}
            className="mt-3 w-full rounded-lg border border-emerald-300 bg-white px-4 py-2 text-sm font-semibold text-emerald-800 transition-colors hover:bg-emerald-100 disabled:cursor-not-allowed disabled:opacity-70"
          >
            {resendLoading
              ? "Sending..."
              : resendCooldown.remaining > 0
                ? `Resend code (${resendCooldown.remaining}s)`
                : "Resend code"}
          </button>
        </div>
      ) : (
        <form onSubmit={handleSubmit} className="space-y-5">
        <div>
          <label
            htmlFor="fullName"
            className="mb-2 block text-sm font-semibold text-gray-800"
          >
            Full name
          </label>
          <input
            id="fullName"
            type="text"
            name="fullName"
            value={form.fullName}
            onChange={handleChange}
            required
            autoComplete="name"
            placeholder="e.g. Amara Diallo"
            className={INPUT_STYLES}
          />
        </div>

        <div>
          <label
            htmlFor="email"
            className="mb-2 block text-sm font-semibold text-gray-800"
          >
            Email
          </label>
          <input
            id="email"
            type="email"
            name="email"
            value={form.email}
            onChange={handleChange}
            required
            autoComplete="email"
            inputMode="email"
            placeholder="you@example.com"
            className={INPUT_STYLES}
          />
        </div>

        <div>
          <label
            htmlFor="password"
            className="mb-2 block text-sm font-semibold text-gray-800"
          >
            Password
          </label>
          <div className="relative">
            <input
              id="password"
              type={passwordVisible ? "text" : "password"}
              name="password"
              value={form.password}
              onChange={handleChange}
              required
              minLength={6}
              autoComplete="new-password"
              placeholder="At least 6 characters"
              className={`${INPUT_STYLES} pr-20`}
              aria-describedby="password-hint"
            />
            <button
              type="button"
              onClick={() => setPasswordVisible((current) => !current)}
              className="absolute right-2 top-1/2 -translate-y-1/2 rounded-lg px-3 py-1.5 text-xs font-semibold text-emerald-700 transition-colors hover:bg-emerald-50 focus:outline-none focus:ring-2 focus:ring-emerald-100"
              aria-label={passwordVisible ? "Hide password" : "Show password"}
            >
              {passwordVisible ? "Hide" : "Show"}
            </button>
          </div>
          <div className="mt-2 flex items-center gap-2" id="password-hint">
            <span
              className={`h-1.5 w-10 rounded-full transition-[background-color] duration-300 ${
                passwordReady ? "bg-emerald-brand" : "bg-gray-200"
              }`}
            />
            <p className="text-xs text-ink-muted">
              {getPasswordHint(form.password)}
            </p>
          </div>
        </div>

        {error ? (
          <div
            className="rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-sm leading-6 text-red-700"
            role="alert"
            aria-live="assertive"
          >
            {error}
          </div>
        ) : null}

        {canResendConfirmation ? (
          <div className="rounded-xl border border-emerald-200 bg-emerald-50 px-4 py-3 text-sm leading-6 text-emerald-900">
            <p>Need a fresh verification code?</p>
            <button
              type="button"
              onClick={handleResendConfirmation}
              disabled={resendLoading || resendCooldown.remaining > 0 || !form.email.trim()}
              className="mt-3 rounded-lg border border-emerald-300 bg-white px-4 py-2 text-sm font-semibold text-emerald-800 transition-colors hover:bg-emerald-100 disabled:cursor-not-allowed disabled:opacity-70"
            >
              {resendLoading
                ? "Sending..."
                : resendCooldown.remaining > 0
                  ? `Resend verification code (${resendCooldown.remaining}s)`
                  : "Resend verification code"}
            </button>
            {resendNotice ? (
              <p className="mt-3 text-emerald-800">{resendNotice}</p>
            ) : null}
            {resendError ? <p className="mt-3 text-red-700">{resendError}</p> : null}
          </div>
        ) : null}

        <button type="submit" disabled={loading} className={PRIMARY_BUTTON_STYLES}>
          {loading ? "Creating account..." : "Create account"}
        </button>
        </form>
      )}
    </AuthShell>
  );
}
