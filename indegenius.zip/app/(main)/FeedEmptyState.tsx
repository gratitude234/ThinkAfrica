import type { ReactNode } from "react";

export default function FeedEmptyState({
  title,
  body,
  cta,
}: {
  title: string;
  body?: string;
  cta?: ReactNode;
}) {
  return (
    <div className="rounded-xl border border-card-border bg-card px-6 py-14 text-center">
      <h2 className="mx-auto max-w-[260px] text-base font-semibold text-ink">{title}</h2>
      {body ? (
        <p className="mx-auto mt-1 max-w-sm text-sm text-ink-muted">{body}</p>
      ) : null}
      {cta ? <div className="mt-5 flex justify-center">{cta}</div> : null}
    </div>
  );
}
