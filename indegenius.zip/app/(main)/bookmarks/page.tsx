"use client";

import { useEffect, useState } from "react";
import type { PostCardData } from "@/components/post/PostCard";
import PostCardImpression from "@/components/post/PostCardImpression";
import { createClient } from "@/lib/supabase/client";

// Two kinds and All. These used to be Blog, Essay and Policy, which named
// the legacy type rather than anything the product has.
const KIND_FILTERS = [
  { label: "All", value: "all" },
  { label: "Posts", value: "post" },
  { label: "Articles", value: "article" },
];

function BookmarkSkeletons() {
  return (
    <div className="space-y-4 animate-pulse motion-reduce:animate-none">
      {[...Array(3)].map((_, index) => (
        <div
          key={index}
          className="rounded-xl border border-gray-200/70 bg-white p-5"
        >
          <div className="space-y-3">
            <div className="h-5 w-16 rounded-full bg-gray-200" />
            <div className="h-6 w-4/5 rounded bg-gray-200" />
            <div className="h-4 w-full rounded bg-gray-100" />
            <div className="h-4 w-3/4 rounded bg-gray-100" />
            <div className="mt-4 flex items-center gap-2 border-t border-gray-100 pt-4">
              <div className="h-3 w-24 rounded bg-gray-200" />
              <div className="h-3 w-28 rounded bg-gray-100" />
              <div className="h-3 w-20 rounded bg-gray-100" />
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}

function kindLabel(filter: string) {
  const match = KIND_FILTERS.find((item) => item.value === filter);
  return match?.label.toLowerCase() ?? "filtered";
}

export default function BookmarksPage() {
  const [allPosts, setAllPosts] = useState<PostCardData[]>([]);
  const [filter, setFilter] = useState<string>("all");
  const [loading, setLoading] = useState(true);
  const [currentUserId, setCurrentUserId] = useState<string | null>(null);

  useEffect(() => {
    const supabase = createClient();

    // The list is fetched from the application, not from the database. The
    // browser has no database credential after the migration, and a reading
    // list is private, so the ownership check lives on the server where the
    // session is. Auth is still read here only to redirect and to label the
    // cards with the current viewer.
    supabase.auth.getUser().then(async ({ data: { user } }) => {
      if (!user) {
        window.location.href = "/login?redirectTo=/bookmarks";
        return;
      }
      setCurrentUserId(user.id);

      try {
        const response = await fetch("/api/bookmarks");
        if (!response.ok) throw new Error(String(response.status));
        const body = (await response.json()) as { posts: PostCardData[] };
        setAllPosts(body.posts ?? []);
      } catch {
        // An empty list and a failed load look the same to this page, which
        // is the pre-existing behaviour: it rendered nothing when the query
        // failed too. The route logs the reason.
        setAllPosts([]);
      } finally {
        setLoading(false);
      }
    });
  }, []);

  const filtered =
    filter === "all"
      ? allPosts
      : allPosts.filter((post) => post.content_kind === filter);

  return (
    <div className="mx-auto max-w-3xl">
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-gray-900">Bookmarks</h1>
        <p className="mt-1 text-sm text-gray-500">
          Posts you&apos;ve saved for later.
        </p>
      </div>

      {loading ? (
        <BookmarkSkeletons />
      ) : allPosts.length === 0 ? (
        <div className="rounded-xl border border-gray-200 bg-white py-20 text-center">
          <svg
            className="mx-auto mb-4 h-12 w-12 text-gray-300"
            fill="none"
            stroke="currentColor"
            viewBox="0 0 24 24"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={1.5}
              d="M5 5a2 2 0 012-2h10a2 2 0 012 2v16l-7-3.5L5 21V5z"
            />
          </svg>
          <p className="font-medium text-gray-500">No bookmarks yet</p>
          <p className="mt-1 text-sm text-gray-500">
            Your saved posts will appear here.
          </p>
        </div>
      ) : (
        <>
          <div className="mb-6 flex flex-wrap gap-2">
            {KIND_FILTERS.map((item) => {
              const count =
                item.value === "all"
                  ? allPosts.length
                  : allPosts.filter((post) => post.content_kind === item.value).length;

              if (item.value !== "all" && count === 0) return null;

              return (
                <button
                  key={item.value}
                  onClick={() => setFilter(item.value)}
                  className={`rounded-full px-4 py-2 text-sm font-medium transition-colors ${
                    filter === item.value
                      ? "bg-emerald-brand text-white"
                      : "border border-gray-200 bg-white text-gray-600 hover:border-emerald-300"
                  }`}
                >
                  {item.label}
                  {count > 0 && <span className="ml-1 opacity-70">{count}</span>}
                </button>
              );
            })}
          </div>

          {filtered.length === 0 ? (
            <div className="rounded-xl border border-gray-200 bg-white py-16 text-center text-gray-500">
              <p className="text-lg font-medium">
                No {kindLabel(filter)} bookmarks
              </p>
              <p className="mt-1 text-sm">
                Save a {kindLabel(filter)} to find it here later.
              </p>
            </div>
          ) : (
            <div className="space-y-4">
              {filtered.map((post) => (
                <PostCardImpression
                  key={post.id}
                  post={post}
                  currentUserId={currentUserId}
                  surface="bookmarks"
                />
              ))}
            </div>
          )}
        </>
      )}
    </div>
  );
}
