import { fireEvent, render, screen } from "@testing-library/react";
import { afterEach, describe, expect, it, vi } from "vitest";
import FeedPreviewPage from "./page";

const mocks = vi.hoisted(() => ({
  requestAuth: vi.fn(),
  like: vi.fn(),
  bookmark: vi.fn(),
}));

// The guest-auth gate every Like/Save button opens instead of writing
// straight through when there's no signed-in user.
vi.mock("@/components/ui/GuestAuthGateProvider", () => ({
  useGuestAuthGate: () => ({ requestAuth: mocks.requestAuth }),
}));

// The same server actions the real Like/Save buttons call. If a click in
// this harness ever reached these, it would be a real Supabase write --
// these mocks let the test prove that never happens.
vi.mock("@/app/(main)/post/[slug]/likeActions", () => ({ togglePostLike: mocks.like }));
vi.mock("@/app/(main)/post/[slug]/bookmarkActions", () => ({ toggleBookmark: mocks.bookmark }));

describe("FeedPreviewPage (dev-only visual fixture harness)", () => {
  afterEach(() => {
    vi.unstubAllEnvs();
    mocks.requestAuth.mockReset();
    mocks.like.mockReset();
    mocks.bookmark.mockReset();
  });

  it("is inaccessible in a production build", () => {
    vi.stubEnv("NODE_ENV", "production");
    expect(() => FeedPreviewPage()).toThrow();
  });

  it("renders the cards and states Home actually has, outside production", () => {
    vi.stubEnv("NODE_ENV", "development");
    render(<FeedPreviewPage />);

    expect(screen.getByText("Home feed visual preview")).toBeInTheDocument();
    expect(screen.getByRole("heading", { name: "The Hidden Cost of Studying Abroad" })).toBeInTheDocument();
    // Research is no longer a product, so the harness has no Research section.
    expect(
      screen.queryByRole("heading", { name: "Community Health Worker Retention After the 2023 Stipend Reform" })
    ).not.toBeInTheDocument();
    expect(screen.getByRole("heading", { name: "No publications to show yet." })).toBeInTheDocument();
    expect(
      screen.getByRole("heading", { name: "Follow writers to see their Posts and Articles here." })
    ).toBeInTheDocument();
    expect(screen.getByText("You're all caught up.")).toBeInTheDocument();
  });

  it("previews none of the modules Phase 2F removed from Home", () => {
    vi.stubEnv("NODE_ENV", "development");
    render(<FeedPreviewPage />);

    for (const retired of [
      /Featured today/i,
      /Editor.s pick/i,
      /intellectual brief/i,
      /Writers to follow/i,
      /Discovery interludes/i,
      /Matches your reading interests/i,
    ]) {
      expect(screen.queryByText(retired)).not.toBeInTheDocument();
    }
  });

  it("never writes to Supabase, even when a pre-liked/saved fixture's engagement button is clicked", () => {
    vi.stubEnv("NODE_ENV", "development");
    render(<FeedPreviewPage />);

    // Every card is rendered with currentUserId={null} -- clicking a
    // pre-"liked" fixture's Unlike control must open the guest sign-in gate
    // instead of calling the real like/bookmark server actions.
    for (const button of screen.getAllByRole("button", { name: /Unlike this item/i })) {
      fireEvent.click(button);
    }
    for (const button of screen.getAllByRole("button", { name: /Remove from saved/i })) {
      fireEvent.click(button);
    }

    expect(mocks.like).not.toHaveBeenCalled();
    expect(mocks.bookmark).not.toHaveBeenCalled();
    expect(mocks.requestAuth).toHaveBeenCalled();
  });
});
