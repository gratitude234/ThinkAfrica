import { fireEvent, render, screen, waitFor } from "@testing-library/react";
import { beforeEach, describe, expect, it, vi } from "vitest";
import FeedEngagementActions from "./FeedEngagementActions";

const mocks = vi.hoisted(() => ({
  requestAuth: vi.fn(),
  like: vi.fn(),
  bookmark: vi.fn(),
}));

vi.mock("@/components/ui/GuestAuthGateProvider", () => ({
  useGuestAuthGate: () => ({ requestAuth: mocks.requestAuth }),
}));

vi.mock("@/app/(main)/post/[slug]/likeActions", () => ({
  togglePostLike: mocks.like,
}));

vi.mock("@/app/(main)/post/[slug]/bookmarkActions", () => ({
  toggleBookmark: mocks.bookmark,
}));

function renderActions(userId: string | null = "user-1") {
  return render(
    <FeedEngagementActions
      postId="post-1"
      slug="a-good-article"
      userId={userId}
      initialLiked={false}
      initialLikeCount={4}
      initialBookmarked={false}
      contentKind="post"
    />
  );
}

describe("FeedEngagementActions", () => {
  beforeEach(() => {
    mocks.requestAuth.mockReset();
    mocks.like.mockReset();
    mocks.bookmark.mockReset();
    window.history.replaceState(null, "", "/?tab=home&type=article");
  });

  it("optimistically likes and reconciles the server count", async () => {
    mocks.like.mockResolvedValue({ error: null, liked: true, count: 8 });
    renderActions();

    fireEvent.click(screen.getByRole("button", { name: "Like this item" }));
    expect(screen.getByText("5")).toBeInTheDocument();

    await waitFor(() => expect(screen.getByText("8")).toBeInTheDocument());
    expect(mocks.like).toHaveBeenCalledWith({ postId: "post-1", nextLiked: true });
  });

  it("rolls a failed like back and exposes the error", async () => {
    mocks.like.mockResolvedValue({ error: "Try again later", liked: false, count: 4 });
    renderActions();

    fireEvent.click(screen.getByRole("button", { name: "Like this item" }));

    await waitFor(() => expect(screen.getByText("Try again later")).toBeInTheDocument());
    expect(screen.getByText("4")).toBeInTheDocument();
    expect(screen.getByRole("button", { name: "Like this item" })).toHaveAttribute("aria-pressed", "false");
  });

  it("optimistically saves and keeps the returned state", async () => {
    mocks.bookmark.mockResolvedValue({ error: null, bookmarked: true });
    renderActions();

    fireEvent.click(screen.getByRole("button", { name: "Save for later" }));

    await waitFor(() => expect(screen.getByRole("button", { name: "Remove from saved" })).toBeInTheDocument());
    expect(mocks.bookmark).toHaveBeenCalledWith({ postId: "post-1", nextBookmarked: true });
  });

  it("opens the contextual sign-in gate for a guest Like instead of changing the count", () => {
    renderActions(null);

    fireEvent.click(screen.getByRole("button", { name: "Like this item" }));

    expect(mocks.requestAuth).toHaveBeenCalledWith("like", { contentKind: "post" });
    expect(mocks.like).not.toHaveBeenCalled();
    expect(screen.getByText("4")).toBeInTheDocument();
  });

  it("opens the contextual sign-in gate for a guest Save instead of changing saved state", () => {
    renderActions(null);

    fireEvent.click(screen.getByRole("button", { name: "Save for later" }));

    expect(mocks.requestAuth).toHaveBeenCalledWith("save", { contentKind: "post" });
    expect(mocks.bookmark).not.toHaveBeenCalled();
    expect(screen.getByRole("button", { name: "Save for later" })).toHaveAttribute(
      "aria-pressed",
      "false"
    );
  });

  it("shares the canonical post URL with the device share sheet", async () => {
    const originalShare = navigator.share;
    const share = vi.fn().mockResolvedValue(undefined);
    Object.defineProperty(navigator, "share", {
      configurable: true,
      value: share,
    });

    try {
      renderActions();
      fireEvent.click(screen.getByRole("button", { name: "Share this item" }));

      await waitFor(() => expect(share).toHaveBeenCalledTimes(1));
      expect(share).toHaveBeenCalledWith(
        expect.objectContaining({
          url: `${window.location.origin}/post/a-good-article`,
        })
      );
      expect(await screen.findByText("Post shared.")).toBeInTheDocument();
    } finally {
      if (originalShare) {
        Object.defineProperty(navigator, "share", {
          configurable: true,
          value: originalShare,
        });
      } else {
        Reflect.deleteProperty(navigator, "share");
      }
    }
  });

  it("keeps zero engagement states inviting instead of printing rows of zeros", () => {
    render(
      <FeedEngagementActions
        postId="post-quiet"
        slug="a-quiet-post"
        userId="user-1"
        initialLiked={false}
        initialLikeCount={0}
        initialBookmarked={false}
        commentCount={0}
        contentKind="post"
      />
    );

    expect(screen.getByRole("button", { name: "Like this item" })).not.toHaveTextContent("0");
    const discussionLink = screen.getByRole("link", {
      name: "0 comments",
    });
    expect(discussionLink).not.toHaveTextContent("0");
    expect(discussionLink).toHaveAttribute(
      "href",
      "/post/a-quiet-post#discussion"
    );
  });
});
