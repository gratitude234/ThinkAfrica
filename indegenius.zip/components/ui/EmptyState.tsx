import Link from "next/link";

interface EmptyStateProps {
  icon?: string;
  title: string;
  description?: string;
  cta?: { label: string; href: string };
}

export default function EmptyState({ icon, title, description, cta }: EmptyStateProps) {
  return (
    <div className="text-center py-16 px-4">
      {icon && <div className="text-4xl mb-3">{icon}</div>}
      <h3 className="text-base font-semibold text-gray-700 mb-1">{title}</h3>
      {description && <p className="text-sm text-gray-400 mb-5">{description}</p>}
      {cta && (
        <Link
          href={cta.href}
          className="inline-flex items-center px-4 py-2 bg-emerald-brand text-white text-sm font-medium rounded-lg hover:bg-[#0E4B37] transition-colors"
        >
          {cta.label}
        </Link>
      )}
    </div>
  );
}

export const EMPTY_STATES = {
  posts: {
    title: "No articles yet.",
    description: "Be the first to share your ideas with Africa.",
    cta: { label: "Write an article", href: "/write" },
  },
} as const;
