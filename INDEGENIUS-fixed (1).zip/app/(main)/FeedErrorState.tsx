export default function FeedErrorState({ onRetry }: { onRetry: () => void }) {
  return (
    <div
      role="alert"
      className="rounded-xl border border-card-border bg-card px-6 py-16 text-center"
    >
      <svg
        className="mx-auto mb-3 h-8 w-8 text-red-500"
        fill="none"
        stroke="currentColor"
        strokeWidth={2}
        viewBox="0 0 24 24"
        aria-hidden="true"
      >
        <path
          strokeLinecap="round"
          strokeLinejoin="round"
          d="M12 9v4m0 4h.01M10.3 3.9L2.8 17a2 2 0 001.7 3h15a2 2 0 001.7-3L13.7 3.9a2 2 0 00-3.4 0z"
        />
      </svg>
      <h2 className="text-base font-semibold text-ink">Couldn&apos;t load your feed</h2>
      <p className="mt-1 text-sm text-ink-muted">We&apos;re having trouble loading publications right now. Please try again.</p>
      <button
        type="button"
        onClick={onRetry}
        className="mt-5 inline-flex min-h-11 items-center rounded-lg bg-emerald-brand px-4 py-2 text-sm font-medium text-white transition-colors hover:bg-[#0E4B37] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-gold focus-visible:ring-offset-2"
      >
        Try again
      </button>
    </div>
  );
}
